# 6. CSV de eventos variáveis

Base: Questor Docs — "Eventos Variáveis - Importação de Planilha - Dados por Arquivo CSV"
(versão 23.3.0.0+, menu Cálculo / Eventos Variáveis / Importação Planilha).

## Estrutura gerada

| Linha | Conteúdo |
| --- | --- |
| 1 | códigos dos eventos, a partir da coluna 3 |
| 2 | letra de cada evento, a partir da coluna 3: **H** horas · **V** valor · **R** referência |
| 3 | título (não importado pelo Questor) |
| 4+ | coluna 1 = código do empregado no Questor; coluna 2 não avaliada; demais = valores |

Separador `;`, vírgula decimal sem milhar, colunas vazias aceitas. Horas seguem a configuração
"Utiliza Hora Centesimal" **da empresa**: 1h30 sai `1,30` (sexagesimal) ou `1,50` (centesimal), e
minuto ≥ 60 é recusado quando a empresa não usa hora centesimal.

## Regras de segurança

- **Nenhum código de evento é fixo no código.** Os eventos vêm do catálogo **de cada empresa**; um
  código válido numa empresa pode ser recusado em outra.
- Empregado repetido no mesmo arquivo é recusado (o Questor duplicaria o lançamento).
- A geração para uso real está bloqueada.

## Como o Pralís monta o arquivo

1. O DP cadastra o **catálogo** da empresa (código do evento no Questor + letras aceitas H/R/V). Evento
   errado não é apagado: é desativado.
2. O DP informa o **código do contrato** de cada colaborador no Questor (CODIGOFUNCCONTR, até 7
   dígitos) em Configuração Questor → Contratos no Questor. É a coluna 1 do CSV.
3. O DP lança, por **competência** (mês), colaborador, evento, letra e valor. Valor com ponto ou
   vírgula decimal, maior que zero, até 4 casas. Para a letra H, o valor é digitado na convenção de
   horas da empresa no Questor (com hora centesimal, 1,50 = 1h30; sem, 1,30 = 1h30) e sai como digitado.
4. A **prévia** agrupa uma linha por contrato e uma coluna por evento+letra, roda o validador do layout
   e lista o que falta, com quem resolve (ex.: "sem código de contrato Questor"; "Utiliza Hora
   Centesimal" não configurado; evento desativado; lançamento de outra competência).
5. O **CSV oficial** só sai com os gates de homologação ligados e a prévia sem pendências. Lançamento
   que já saiu em CSV oficial só sai de novo com motivo, porque o Questor duplica o que for importado
   duas vezes. Lançamento exportado não pode ser apagado.

Arquivo: `;`, vírgula decimal sem milhar, CR+LF, UTF-8, nome `eventos-variaveis-AAAA-MM-<sha>.csv`,
`text/csv; charset=utf-8`. Nome do colaborador (coluna 2, não avaliada pelo Questor) sai sem `;` nem
quebra de linha.

## Situação (22/10/2026)

| Item | Situação |
| --- | --- |
| Catálogo: `GET/POST /api/conplus/questor/eventos`, `PATCH …/eventos/:id` (descrição/ativo) | **Implementado e testado** |
| Lançamentos: `GET/POST …/eventos/lancamentos`, `DELETE …/lancamentos/:id` (só não exportados) | **Implementado e testado** |
| Prévia: `POST /api/conplus/questor/exportacoes/eventos/previa` (conteúdo, pendências, diagnósticos) | **Implementado e testado** |
| CSV oficial: `POST /api/conplus/questor/exportacoes/eventos/download` (gates + auditoria + vínculo dos lançamentos) | **Implementado e testado**; bloqueado até a homologação |
| Histórico e novo download | Os mesmos do TXT (documento 5) |
| Código do empregado (coluna 1) | **Implementado**: `colaboradores_vinculos.questor_codigo_contrato` (migration 0069), único por empresa |
| Tabelas | Migration `0068_questor_exportacoes` (catálogo, lançamentos, auditoria), registrada no journal |
| Permissão | `conplus_exportar_eventos` (DP). Lançamento ou vínculo de outra empresa responde como inexistente |

**Depende da Conplus:** o **modelo CSV anexado ao e-mail de 07/10/2026 não foi recebido** pelo time
técnico. Precisamos dele para conferir o arquivo do Pralís byte a byte, e do catálogo de eventos (código
e letra H/R/V) **por empresa**. Também precisamos da confirmação de que a coluna 1 é o código do
contrato (CODIGOFUNCCONTR). Nenhum código de evento foi inventado: os dos testes são fictícios (9xx).
