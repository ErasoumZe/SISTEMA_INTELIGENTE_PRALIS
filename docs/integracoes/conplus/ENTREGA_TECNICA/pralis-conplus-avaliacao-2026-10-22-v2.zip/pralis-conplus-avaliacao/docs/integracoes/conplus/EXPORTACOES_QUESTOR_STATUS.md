# Exportações Questor — estado técnico

Atualizado em 22/10/2026 (fim do dia). Detalhe de rotas e regras: `ENTREGA_TECNICA/05` (TXT),
`ENTREGA_TECNICA/06` (CSV) e `ENTREGA_TECNICA/10` (migrations).

## Implementado e testado

- Geradores puros do TXT de admissão (A/B/C/D) e do CSV de eventos variáveis no pacote compartilhado,
  validados sem chamadas à Conplus, Google ou banco.
- **TXT de admissão**: prévia, TXT técnico (`TECNICO-NAO-IMPORTAR-…`, auditoria `previa`) e TXT oficial
  (gates de homologação + arquivo sem pendência; tentativa recusada fica na auditoria como `bloqueado`).
- **CSV de eventos variáveis**: catálogo por empresa (cadastrar, desativar), lançamentos por competência
  (criar, remover se não exportado), prévia com o conteúdo do arquivo e pendências, CSV oficial com os
  mesmos gates. A coluna 1 é o código do contrato Questor do vínculo (Configuração Questor → Contratos
  no Questor).
- **Auditoria e histórico**: SHA-256, idempotência por conteúdo, motivo obrigatório para reexportar o
  que já saiu em arquivo oficial, arquivo no storage endereçado pelo SHA e novo download conferido
  contra a auditoria.
- Tudo limitado à empresa da sessão; permissões `conplus_exportar_admissoes` e
  `conplus_exportar_eventos` (DP).
- Tela `/conplus/exportar` (Departamento Pessoal → Exportações Questor), validada no navegador em
  1440, 1024, 768 e 390 px.

## Migration

`0068_questor_exportacoes` está no journal com snapshot (o snapshot foi gerado fora do repositório,
contornando o `ENOMEM` do ambiente, e o SQL original foi mantido). A cadeia 0000→0069 sobe em banco
vazio pelo comando oficial do deploy. A homologação (5544) recebeu 0064–0069 em 22/10/2026, depois de
backup e ensaio (registro em `HOMOLOGACAO_MIGRATIONS_0064_0069.md`).

## Continua bloqueado (depende da Conplus)

- TXT oficial: respostas e tabelas do `ENTREGA_TECNICA/07` (sem elas o arquivo sempre tem pendências).
- CSV oficial: modelo CSV do e-mail de 07/10/2026 e o catálogo de eventos de cada empresa.
- Os gates `CONPLUS_QUESTOR_EXPORT_ENABLED` e `CONPLUS_QUESTOR_EXPORT_HOMOLOGADA` só são ligados depois
  dessa confirmação.
