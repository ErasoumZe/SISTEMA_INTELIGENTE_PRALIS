import { and, desc, eq, inArray } from "drizzle-orm";
import {
  perfisUsuarios,
  questorExportacoes,
  questorExportacoesAdmissoes,
  questorExportacoesEventosVariaveis
} from "@padaria/db/schema";
import { banco } from "../banco/conexao.js";

/** Auditoria das exportações Questor (tabelas da migration 0068). */

export type TipoExportacaoQuestor = "admissao" | "eventos_variaveis";
export type ResultadoExportacaoQuestor = "previa" | "gerado" | "bloqueado" | "falhou";

const colunasHistorico = {
  id: questorExportacoes.id,
  tipo: questorExportacoes.tipo,
  competencia: questorExportacoes.competencia,
  layoutVersao: questorExportacoes.layoutVersao,
  sha256: questorExportacoes.sha256,
  resultado: questorExportacoes.resultado,
  nomeArquivo: questorExportacoes.nomeArquivo,
  caminhoArquivo: questorExportacoes.caminhoArquivo,
  diagnosticos: questorExportacoes.diagnosticos,
  motivoRegeracao: questorExportacoes.motivoRegeracao,
  geradoPorNome: perfisUsuarios.nome,
  geradoEm: questorExportacoes.geradoEm
};

export function listarQuestorExportacoesRepository(empresaId: string, tipo?: TipoExportacaoQuestor, limite = 50) {
  const condicoes = [eq(questorExportacoes.empresaId, empresaId)];
  if (tipo) condicoes.push(eq(questorExportacoes.tipo, tipo));
  return banco
    .select(colunasHistorico)
    .from(questorExportacoes)
    .leftJoin(perfisUsuarios, eq(perfisUsuarios.usuarioId, questorExportacoes.geradoPor))
    .where(and(...condicoes))
    .orderBy(desc(questorExportacoes.criadoEm))
    .limit(limite);
}

export async function obterQuestorExportacaoRepository(empresaId: string, id: string) {
  const [linha] = await banco
    .select(colunasHistorico)
    .from(questorExportacoes)
    .leftJoin(perfisUsuarios, eq(perfisUsuarios.usuarioId, questorExportacoes.geradoPor))
    .where(and(eq(questorExportacoes.id, id), eq(questorExportacoes.empresaId, empresaId)))
    .limit(1);
  return linha ?? null;
}

export async function buscarExportacaoPorChaveRepository(
  empresaId: string,
  tipo: TipoExportacaoQuestor,
  chaveIdempotencia: string
) {
  const [linha] = await banco
    .select({ id: questorExportacoes.id, nomeArquivo: questorExportacoes.nomeArquivo })
    .from(questorExportacoes)
    .where(
      and(
        eq(questorExportacoes.empresaId, empresaId),
        eq(questorExportacoes.tipo, tipo),
        eq(questorExportacoes.chaveIdempotencia, chaveIdempotencia)
      )
    )
    .limit(1);
  return linha ?? null;
}

/** Processos da lista que já saíram num arquivo OFICIAL (`gerado`) desta empresa. */
export async function processosJaExportadosRepository(empresaId: string, processoIds: readonly string[]) {
  const linhas = await banco
    .selectDistinct({ processoId: questorExportacoesAdmissoes.processoId })
    .from(questorExportacoesAdmissoes)
    .innerJoin(
      questorExportacoes,
      and(
        eq(questorExportacoes.id, questorExportacoesAdmissoes.exportacaoId),
        eq(questorExportacoes.empresaId, questorExportacoesAdmissoes.empresaId)
      )
    )
    .where(
      and(
        eq(questorExportacoesAdmissoes.empresaId, empresaId),
        inArray(questorExportacoesAdmissoes.processoId, [...processoIds]),
        eq(questorExportacoes.resultado, "gerado")
      )
    );
  return linhas.map((linha) => linha.processoId);
}

/** Lançamentos da lista que já saíram num CSV OFICIAL (`gerado`) desta empresa. */
export async function lancamentosJaExportadosRepository(empresaId: string, lancamentoIds: readonly string[]) {
  const linhas = await banco
    .selectDistinct({ lancamentoId: questorExportacoesEventosVariaveis.lancamentoId })
    .from(questorExportacoesEventosVariaveis)
    .innerJoin(
      questorExportacoes,
      and(
        eq(questorExportacoes.id, questorExportacoesEventosVariaveis.exportacaoId),
        eq(questorExportacoes.empresaId, questorExportacoesEventosVariaveis.empresaId)
      )
    )
    .where(
      and(
        eq(questorExportacoesEventosVariaveis.empresaId, empresaId),
        inArray(questorExportacoesEventosVariaveis.lancamentoId, [...lancamentoIds]),
        eq(questorExportacoes.resultado, "gerado")
      )
    );
  return linhas.map((linha) => linha.lancamentoId);
}

export type NovaExportacaoQuestor = {
  empresaId: string;
  tipo: TipoExportacaoQuestor;
  competencia: string | null;
  layoutVersao: string;
  sha256: string;
  chaveIdempotencia: string;
  resultado: ResultadoExportacaoQuestor;
  nomeArquivo: string | null;
  caminhoArquivo: string | null;
  diagnosticos: string[];
  motivoRegeracao: string | null;
  geradoPor: string;
  processoIds?: readonly string[];
  lancamentoIds?: readonly string[];
};

/**
 * Registra a exportação e os vínculos (processos ou lançamentos) numa transação. `criada: false` =
 * a mesma chave de idempotência já existia; nada é gravado e o registro existente é devolvido.
 */
export async function registrarExportacaoQuestorRepository(
  dados: NovaExportacaoQuestor
): Promise<{ id: string; criada: boolean }> {
  const { processoIds = [], lancamentoIds = [], ...linha } = dados;
  return banco.transaction(async (tx) => {
    const [inserida] = await tx
      .insert(questorExportacoes)
      .values(linha)
      .onConflictDoNothing({
        target: [questorExportacoes.empresaId, questorExportacoes.tipo, questorExportacoes.chaveIdempotencia]
      })
      .returning({ id: questorExportacoes.id });
    if (!inserida) {
      const [existente] = await tx
        .select({ id: questorExportacoes.id })
        .from(questorExportacoes)
        .where(
          and(
            eq(questorExportacoes.empresaId, linha.empresaId),
            eq(questorExportacoes.tipo, linha.tipo),
            eq(questorExportacoes.chaveIdempotencia, linha.chaveIdempotencia)
          )
        )
        .limit(1);
      if (!existente) throw new Error("Exportação Questor concorrente não encontrada");
      return { id: existente.id, criada: false };
    }
    if (processoIds.length) {
      await tx
        .insert(questorExportacoesAdmissoes)
        .values(
          processoIds.map((processoId) => ({ exportacaoId: inserida.id, processoId, empresaId: linha.empresaId }))
        );
    }
    if (lancamentoIds.length) {
      await tx.insert(questorExportacoesEventosVariaveis).values(
        lancamentoIds.map((lancamentoId) => ({
          exportacaoId: inserida.id,
          lancamentoId,
          empresaId: linha.empresaId
        }))
      );
    }
    return { id: inserida.id, criada: true };
  });
}
