import type { PerfilUsuario } from "@padaria/shared";
import type { DadosExternos } from "@padaria/shared/api";
import {
  ERROS_EXPORTACAO_QUESTOR,
  VERSAO_LAYOUT_EVENTOS_QUESTOR,
  prepararCsvEventosVariaveis,
  questorEventosVariaveisCatalogoSchema,
  questorEventosVariaveisGeracaoSchema,
  questorEventosVariaveisLancamentoSchema,
  questorEventosVariaveisPreviaSchema,
  questorEventosVariaveisQuerySchema,
  questorEventoVariavelAtualizacaoSchema,
  type LancamentoParaCsvQuestor,
  type QuestorEventosVariaveisPreviaDto,
  type QuestorLancamentoVariavelDto
} from "@padaria/shared/conplus";
import { atorDoPerfil, empresaDoAtor } from "../admissoes/ator.js";
import { conflito, naoEncontrado, naoProcessavel } from "../erros.js";
import { comMigrationQuestor } from "./questor-comum.service.js";
import {
  exigirExportacaoHomologada,
  exportacaoQuestorHomologada,
  registrarArquivoQuestor,
  registrarBloqueioQuestor,
  sha256Texto,
  type ArquivoExportadoQuestor
} from "./questor-exportacao.service.js";
import {
  buscarExportacaoPorChaveRepository,
  lancamentosJaExportadosRepository
} from "./questor-exportacoes.repository.js";
import {
  atualizarEventoVariavelRepository,
  buscarLancamentosVariaveisRepository,
  inserirEventoVariavelRepository,
  inserirLancamentoVariavelRepository,
  lancamentosComArquivoRepository,
  lerHoraCentesimalRepository,
  listarEventosVariaveisRepository,
  listarLancamentosVariaveisRepository,
  removerLancamentoVariavelRepository,
  type LancamentoVariavelCompleto
} from "./questor-eventos.repository.js";

/**
 * Eventos variáveis do Questor: catálogo por empresa, lançamentos por competência e o CSV de
 * importação (layout "Eventos Variáveis - Importação de Planilha", Questor 23.3+). Nenhum código de
 * evento é fixo: todos vêm do catálogo que o DP cadastra a partir do Questor de cada empresa.
 */

// --- Catálogo ----------------------------------------------------------------------------------------

export function listarEventosVariaveis(perfil?: PerfilUsuario) {
  return comMigrationQuestor(() => listarEventosVariaveisRepository(empresaDoAtor(perfil)));
}

export async function criarEventoVariavel(body: DadosExternos, perfil?: PerfilUsuario) {
  const dados = questorEventosVariaveisCatalogoSchema.parse(body);
  const criado = await comMigrationQuestor(() =>
    inserirEventoVariavelRepository(empresaDoAtor(perfil), { ...dados, criadoPor: atorDoPerfil(perfil) })
  );
  if (criado.length === 0) throw conflito("O evento já existe no catálogo desta empresa", "QUESTOR_EVENTO_DUPLICADO");
  return criado[0];
}

export async function atualizarEventoVariavel(id: string, body: DadosExternos, perfil?: PerfilUsuario) {
  const dados = questorEventoVariavelAtualizacaoSchema.parse(body);
  const atualizado = await comMigrationQuestor(() =>
    atualizarEventoVariavelRepository(empresaDoAtor(perfil), id, {
      ...(dados.descricao !== undefined ? { descricao: dados.descricao } : {}),
      ...(dados.ativo !== undefined ? { ativo: dados.ativo } : {})
    })
  );
  if (!atualizado) throw naoEncontrado("Evento não encontrado no catálogo da empresa");
  return atualizado;
}

// --- Lançamentos -------------------------------------------------------------------------------------

async function paraDto(
  empresaId: string,
  linhas: LancamentoVariavelCompleto[]
): Promise<QuestorLancamentoVariavelDto[]> {
  const exportados = new Set(
    linhas.length
      ? await lancamentosJaExportadosRepository(
          empresaId,
          linhas.map((linha) => linha.id)
        )
      : []
  );
  return linhas.map((linha) => ({
    id: linha.id,
    competencia: linha.competencia,
    vinculoId: linha.vinculoId,
    colaboradorNome: linha.colaboradorNome,
    matricula: linha.matricula,
    questorCodigoContrato: linha.questorCodigoContrato,
    eventoId: linha.eventoId,
    eventoCodigo: linha.eventoCodigo,
    eventoDescricao: linha.eventoDescricao,
    unidade: linha.unidade,
    valor: linha.valor,
    exportado: exportados.has(linha.id)
  }));
}

export async function listarLancamentosVariaveis(query: DadosExternos, perfil?: PerfilUsuario) {
  const filtro = questorEventosVariaveisQuerySchema.parse(query ?? {});
  const empresaId = empresaDoAtor(perfil);
  return comMigrationQuestor(async () =>
    paraDto(empresaId, await listarLancamentosVariaveisRepository(empresaId, filtro.competencia))
  );
}

export async function criarLancamentoVariavel(body: DadosExternos, perfil?: PerfilUsuario) {
  const dados = questorEventosVariaveisLancamentoSchema.parse(body);
  const empresaId = empresaDoAtor(perfil);
  return comMigrationQuestor(async () => {
    const resultado = await inserirLancamentoVariavelRepository(empresaId, {
      ...dados,
      criadoPor: atorDoPerfil(perfil)
    });
    if (resultado.kind === "vinculo_inexistente") throw naoEncontrado("Vínculo do colaborador não encontrado");
    if (resultado.kind === "evento_inexistente") throw naoEncontrado("Evento não encontrado no catálogo da empresa");
    if (resultado.kind === "evento_inativo")
      throw naoProcessavel("O evento está desativado no catálogo da empresa", "QUESTOR_EVENTO_INATIVO");
    if (resultado.kind === "unidade_nao_catalogada")
      throw naoProcessavel("A unidade não está autorizada no catálogo do evento", "QUESTOR_UNIDADE_NAO_CATALOGADA");
    if (resultado.kind === "duplicado")
      throw conflito(
        "Já existe lançamento para este colaborador, competência e evento",
        "QUESTOR_LANCAMENTO_DUPLICADO"
      );
    const [criado] = await paraDto(empresaId, await buscarLancamentosVariaveisRepository(empresaId, [resultado.id]));
    return criado;
  });
}

export async function removerLancamentoVariavel(id: string, perfil?: PerfilUsuario) {
  const empresaId = empresaDoAtor(perfil);
  await comMigrationQuestor(async () => {
    if ((await lancamentosComArquivoRepository(empresaId, [id])).length) {
      throw conflito(
        "Este lançamento já saiu em arquivo e fica no histórico; lance o ajuste na competência seguinte",
        ERROS_EXPORTACAO_QUESTOR.lancamentoExportado
      );
    }
    if (!(await removerLancamentoVariavelRepository(empresaId, id))) throw naoEncontrado("Lançamento não encontrado");
  });
}

// --- Prévia e CSV ------------------------------------------------------------------------------------

async function montarCsv(empresaId: string, competencia: string, lancamentoIds: readonly string[]) {
  const [lancamentos, horaCentesimal] = await Promise.all([
    buscarLancamentosVariaveisRepository(empresaId, lancamentoIds),
    lerHoraCentesimalRepository(empresaId)
  ]);
  // Lançamento de outra empresa (ou inexistente) some na consulta: a resposta é a mesma para os dois.
  if (lancamentos.length !== lancamentoIds.length) {
    throw naoEncontrado("Um ou mais lançamentos não pertencem à empresa do usuário");
  }
  const csv = prepararCsvEventosVariaveis(
    competencia,
    lancamentos.map((linha): LancamentoParaCsvQuestor => ({ ...linha })),
    horaCentesimal
  );
  return { csv, lancamentos };
}

const descrever = (csv: ReturnType<typeof prepararCsvEventosVariaveis>) =>
  csv.diagnosticos.map(
    (item) => `Linha ${item.linha}${item.coluna ? `, coluna ${item.coluna}` : ""}: ${item.mensagem}`
  );

export async function validarPreviaEventosVariaveis(
  body: DadosExternos,
  perfil?: PerfilUsuario
): Promise<QuestorEventosVariaveisPreviaDto> {
  const dados = questorEventosVariaveisPreviaSchema.parse(body);
  const empresaId = empresaDoAtor(perfil);
  const homologada = exportacaoQuestorHomologada();
  return comMigrationQuestor(async () => {
    const { csv } = await montarCsv(empresaId, dados.competencia, dados.lancamentoIds);
    const jaExportados = await lancamentosJaExportadosRepository(empresaId, dados.lancamentoIds);
    return {
      tipo: "eventos_variaveis",
      competencia: dados.competencia,
      exportacaoDisponivel: homologada,
      homologacaoConplusConfirmada: homologada,
      bloqueio: homologada ? null : ERROS_EXPORTACAO_QUESTOR.naoHomologada,
      quantidadeRegistros: dados.lancamentoIds.length,
      quantidadeEmpregados: csv.quantidadeEmpregados,
      valido: csv.valido,
      pendencias: csv.pendencias,
      diagnosticos: descrever(csv),
      jaExportados: jaExportados.length,
      conteudo: csv.conteudo
    };
  });
}

/** CSV oficial: gates de homologação + arquivo válido + lançamento já exportado só com motivo. */
export async function gerarCsvEventosVariaveis(
  body: DadosExternos,
  perfil?: PerfilUsuario
): Promise<ArquivoExportadoQuestor> {
  exigirExportacaoHomologada();
  const dados = questorEventosVariaveisGeracaoSchema.parse(body);
  const empresaId = empresaDoAtor(perfil);
  const usuarioId = atorDoPerfil(perfil);
  return comMigrationQuestor(async () => {
    const { csv } = await montarCsv(empresaId, dados.competencia, dados.lancamentoIds);
    if (!csv.valido) {
      const motivos = [...csv.pendencias, ...descrever(csv)];
      await registrarBloqueioQuestor({
        empresaId,
        usuarioId,
        tipo: "eventos_variaveis",
        competencia: dados.competencia,
        layoutVersao: VERSAO_LAYOUT_EVENTOS_QUESTOR,
        conteudo: csv.conteudo || motivos.join("\n"),
        diagnosticos: motivos
      });
      throw naoProcessavel("O CSV de eventos variáveis tem pendências", ERROS_EXPORTACAO_QUESTOR.invalida, motivos);
    }
    const repetido = await buscarExportacaoPorChaveRepository(
      empresaId,
      "eventos_variaveis",
      `gerado:${sha256Texto(csv.conteudo)}`
    );
    if (!repetido) {
      const jaExportados = await lancamentosJaExportadosRepository(empresaId, dados.lancamentoIds);
      if (jaExportados.length && !dados.motivoRegeracao) {
        // O Questor DUPLICA lançamentos importados duas vezes: reexportar exige decisão explícita.
        throw conflito(
          "Há lançamento nesta seleção que já saiu em arquivo oficial. Informe o motivo para gerar de novo.",
          ERROS_EXPORTACAO_QUESTOR.jaExportado,
          jaExportados
        );
      }
    }
    const mes = dados.competencia.slice(0, 7);
    return registrarArquivoQuestor({
      empresaId,
      usuarioId,
      tipo: "eventos_variaveis",
      resultado: "gerado",
      competencia: dados.competencia,
      layoutVersao: VERSAO_LAYOUT_EVENTOS_QUESTOR,
      conteudo: csv.conteudo,
      extensao: "csv",
      nomeArquivo: (sha) => `eventos-variaveis-${mes}-${sha.slice(0, 12)}.csv`,
      mimeType: "text/csv; charset=utf-8",
      motivoRegeracao: dados.motivoRegeracao ?? null,
      lancamentoIds: dados.lancamentoIds
    });
  });
}
