import type { FastifyInstance, FastifyReply } from "fastify";
import { processoParamsSchema } from "@padaria/shared/admissoes";
import { ok } from "@padaria/shared/api";
import { ROTAS_EXPORTACAO_QUESTOR } from "@padaria/shared/conplus";
import { exigirAutenticacao, exigirPermissao } from "../auth/guards.js";
import {
  baixarArquivoExportacaoQuestor,
  gerarArquivoAdmissaoQuestor,
  gerarArquivoTecnicoAdmissaoQuestor,
  listarHistoricoExportacoesQuestor,
  prepararPreviaAdmissaoQuestor,
  type ArquivoExportadoQuestor
} from "./questor-exportacao.service.js";

/** Resposta de arquivo: anexo, tipo explícito, e SHA/ID para a tela conferir e o histórico achar. */
export function enviarArquivoQuestor(
  reply: FastifyReply,
  arquivo: Pick<ArquivoExportadoQuestor, "nomeArquivo" | "mimeType" | "sha256"> & {
    conteudo: string | Buffer;
    exportacaoId?: string;
    reutilizado?: boolean;
  }
) {
  reply
    .type(arquivo.mimeType)
    .header("Content-Disposition", `attachment; filename="${arquivo.nomeArquivo}"`)
    .header("X-Questor-Sha256", arquivo.sha256)
    .header("Cache-Control", "no-store");
  if (arquivo.exportacaoId) reply.header("X-Questor-Exportacao-Id", arquivo.exportacaoId);
  if (arquivo.reutilizado !== undefined) reply.header("X-Questor-Reutilizado", String(arquivo.reutilizado));
  return reply.send(arquivo.conteudo);
}

export async function registrarRotasQuestorExportacao(app: FastifyInstance): Promise<void> {
  const admissoes = { preHandler: exigirPermissao("conplus_exportar_admissoes") };

  app.post(ROTAS_EXPORTACAO_QUESTOR.admissoesPrevia, admissoes, async (request) =>
    ok(await prepararPreviaAdmissaoQuestor(request.body, request.perfilUsuario))
  );
  app.post(ROTAS_EXPORTACAO_QUESTOR.admissoesTecnico, admissoes, async (request, reply) =>
    enviarArquivoQuestor(reply, await gerarArquivoTecnicoAdmissaoQuestor(request.body, request.perfilUsuario))
  );
  app.post(ROTAS_EXPORTACAO_QUESTOR.admissoesDownload, admissoes, async (request, reply) =>
    enviarArquivoQuestor(reply, await gerarArquivoAdmissaoQuestor(request.body, request.perfilUsuario))
  );
  app.get(ROTAS_EXPORTACAO_QUESTOR.historico, admissoes, async (request) =>
    ok(await listarHistoricoExportacoesQuestor(request.query, request.perfilUsuario))
  );
  // A permissão depende do tipo da exportação (admissão ou eventos): o serviço confere depois de achar.
  app.get(
    ROTAS_EXPORTACAO_QUESTOR.arquivo,
    { preHandler: async (request, reply) => void (await exigirAutenticacao(request, reply)) },
    async (request, reply) => {
      const { id } = processoParamsSchema.parse(request.params);
      return enviarArquivoQuestor(reply, await baixarArquivoExportacaoQuestor(id, request.perfilUsuario));
    }
  );
}
