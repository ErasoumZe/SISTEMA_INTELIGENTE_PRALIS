import { and, asc, eq, inArray } from "drizzle-orm";
import {
  colaboradores,
  colaboradoresVinculos,
  questorConfiguracoes,
  questorEventosVariaveis,
  questorEventosVariaveisLancamentos,
  questorExportacoesEventosVariaveis
} from "@padaria/db/schema";
import { banco } from "../banco/conexao.js";

export function listarEventosVariaveisRepository(empresaId: string) {
  return banco
    .select()
    .from(questorEventosVariaveis)
    .where(eq(questorEventosVariaveis.empresaId, empresaId))
    .orderBy(asc(questorEventosVariaveis.codigo));
}

export function inserirEventoVariavelRepository(
  empresaId: string,
  dados: { codigo: string; descricao: string; unidades: string[]; criadoPor: string }
) {
  return banco
    .insert(questorEventosVariaveis)
    .values({ empresaId, ...dados })
    .onConflictDoNothing()
    .returning();
}

export async function atualizarEventoVariavelRepository(
  empresaId: string,
  id: string,
  dados: { descricao?: string; ativo?: boolean }
) {
  const [linha] = await banco
    .update(questorEventosVariaveis)
    .set({ ...dados, atualizadoEm: new Date() })
    .where(and(eq(questorEventosVariaveis.id, id), eq(questorEventosVariaveis.empresaId, empresaId)))
    .returning();
  return linha ?? null;
}

export async function inserirLancamentoVariavelRepository(
  empresaId: string,
  dados: {
    competencia: string;
    vinculoId: string;
    eventoId: string;
    unidade: "H" | "R" | "V";
    valor: string;
    criadoPor: string;
  }
) {
  const [vinculo] = await banco
    .select({ id: colaboradoresVinculos.id })
    .from(colaboradoresVinculos)
    .where(and(eq(colaboradoresVinculos.id, dados.vinculoId), eq(colaboradoresVinculos.empresaId, empresaId)))
    .limit(1);
  if (!vinculo) return { kind: "vinculo_inexistente" as const };

  const [evento] = await banco
    .select({
      id: questorEventosVariaveis.id,
      unidades: questorEventosVariaveis.unidades,
      ativo: questorEventosVariaveis.ativo
    })
    .from(questorEventosVariaveis)
    .where(and(eq(questorEventosVariaveis.id, dados.eventoId), eq(questorEventosVariaveis.empresaId, empresaId)))
    .limit(1);
  if (!evento) return { kind: "evento_inexistente" as const };
  if (!evento.ativo) return { kind: "evento_inativo" as const };
  if (!evento.unidades.includes(dados.unidade)) return { kind: "unidade_nao_catalogada" as const };

  const [linha] = await banco
    .insert(questorEventosVariaveisLancamentos)
    .values({ empresaId, ...dados })
    .onConflictDoNothing()
    .returning({ id: questorEventosVariaveisLancamentos.id });
  return linha ? { kind: "criado" as const, id: linha.id } : { kind: "duplicado" as const };
}

/**
 * Remove um lançamento que ainda não saiu em arquivo. Lançamento exportado fica: a FK da auditoria
 * (`ON DELETE RESTRICT`) também impede, mas o serviço responde antes com mensagem clara.
 */
export async function removerLancamentoVariavelRepository(empresaId: string, id: string) {
  const [removido] = await banco
    .delete(questorEventosVariaveisLancamentos)
    .where(
      and(eq(questorEventosVariaveisLancamentos.id, id), eq(questorEventosVariaveisLancamentos.empresaId, empresaId))
    )
    .returning({ id: questorEventosVariaveisLancamentos.id });
  return removido ?? null;
}

/** Lançamento + vínculo + colaborador + evento: tudo que o CSV e a tela precisam. */
function consultaLancamentos() {
  return banco
    .select({
      id: questorEventosVariaveisLancamentos.id,
      competencia: questorEventosVariaveisLancamentos.competencia,
      vinculoId: questorEventosVariaveisLancamentos.vinculoId,
      colaboradorNome: colaboradores.nome,
      matricula: colaboradoresVinculos.matricula,
      questorCodigoContrato: colaboradoresVinculos.questorCodigoContrato,
      eventoId: questorEventosVariaveisLancamentos.eventoId,
      eventoCodigo: questorEventosVariaveis.codigo,
      eventoDescricao: questorEventosVariaveis.descricao,
      eventoAtivo: questorEventosVariaveis.ativo,
      eventoUnidades: questorEventosVariaveis.unidades,
      unidade: questorEventosVariaveisLancamentos.unidade,
      valor: questorEventosVariaveisLancamentos.valor
    })
    .from(questorEventosVariaveisLancamentos)
    .innerJoin(
      colaboradoresVinculos,
      and(
        eq(colaboradoresVinculos.id, questorEventosVariaveisLancamentos.vinculoId),
        eq(colaboradoresVinculos.empresaId, questorEventosVariaveisLancamentos.empresaId)
      )
    )
    .innerJoin(
      colaboradores,
      and(
        eq(colaboradores.id, colaboradoresVinculos.colaboradorId),
        eq(colaboradores.empresaId, colaboradoresVinculos.empresaId)
      )
    )
    .innerJoin(
      questorEventosVariaveis,
      and(
        eq(questorEventosVariaveis.id, questorEventosVariaveisLancamentos.eventoId),
        eq(questorEventosVariaveis.empresaId, questorEventosVariaveisLancamentos.empresaId)
      )
    );
}

export type LancamentoVariavelCompleto = Awaited<ReturnType<typeof buscarLancamentosVariaveisRepository>>[number];

export function buscarLancamentosVariaveisRepository(empresaId: string, ids: readonly string[]) {
  return consultaLancamentos().where(
    and(
      eq(questorEventosVariaveisLancamentos.empresaId, empresaId),
      inArray(questorEventosVariaveisLancamentos.id, [...ids])
    )
  );
}

export function listarLancamentosVariaveisRepository(empresaId: string, competencia?: string) {
  const condicoes = [eq(questorEventosVariaveisLancamentos.empresaId, empresaId)];
  if (competencia) condicoes.push(eq(questorEventosVariaveisLancamentos.competencia, competencia));
  return consultaLancamentos()
    .where(and(...condicoes))
    .orderBy(
      asc(questorEventosVariaveisLancamentos.competencia),
      asc(colaboradores.nome),
      asc(questorEventosVariaveis.codigo)
    );
}

/** Ids da lista que aparecem em QUALQUER arquivo gravado (técnico ou oficial) — não podem ser apagados. */
export async function lancamentosComArquivoRepository(empresaId: string, ids: readonly string[]) {
  if (!ids.length) return [];
  const linhas = await banco
    .selectDistinct({ lancamentoId: questorExportacoesEventosVariaveis.lancamentoId })
    .from(questorExportacoesEventosVariaveis)
    .where(
      and(
        eq(questorExportacoesEventosVariaveis.empresaId, empresaId),
        inArray(questorExportacoesEventosVariaveis.lancamentoId, [...ids])
      )
    );
  return linhas.map((linha) => linha.lancamentoId);
}

/** "Utiliza Hora Centesimal" da empresa (E2). `null` = ainda não configurado. */
export async function lerHoraCentesimalRepository(empresaId: string): Promise<boolean | null> {
  const [linha] = await banco
    .select({ utilizaHoraCentesimal: questorConfiguracoes.utilizaHoraCentesimal })
    .from(questorConfiguracoes)
    .where(eq(questorConfiguracoes.empresaId, empresaId))
    .limit(1);
  return linha?.utilizaHoraCentesimal ?? null;
}
