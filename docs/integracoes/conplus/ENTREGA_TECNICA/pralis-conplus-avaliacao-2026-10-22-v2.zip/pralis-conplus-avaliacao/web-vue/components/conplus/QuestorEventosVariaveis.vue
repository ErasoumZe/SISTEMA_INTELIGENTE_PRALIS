<script setup lang="ts">
import {
  ERROS_EXPORTACAO_QUESTOR,
  formatarValorEventoVariavel,
  ROTAS_EXPORTACAO_QUESTOR,
  ROTAS_QUESTOR,
  questorEventosVariaveisLancamentoSchema,
  type ContratoColaboradorQuestorDto,
  type QuestorEventosVariaveisPreviaDto,
  type QuestorEventoVariavelDto,
  type QuestorLancamentoVariavelDto
} from "@padaria/shared";
import QuestorEventosCatalogo from "~/components/conplus/QuestorEventosCatalogo.vue";
import { ErroApiCliente } from "~/composables/useApi";
import { useArquivoQuestor } from "~/composables/useArquivoQuestor";

const emit = defineEmits<{ gerado: [] }>();

const { apiGet, apiPost, apiDelete } = useApi();
const { baixar } = useArquivoQuestor();
const eventos = ref<QuestorEventoVariavelDto[]>([]);
const colaboradores = ref<ContratoColaboradorQuestorDto[]>([]);
const mes = ref(new Date().toISOString().slice(0, 7));
const competencia = computed(() => `${mes.value}-01`);
const lancamentos = ref<QuestorLancamentoVariavelDto[]>([]);
const selecionados = ref<string[]>([]);
const novo = reactive({ vinculoId: "", eventoId: "", unidade: "", valor: "" });
const previa = ref<QuestorEventosVariaveisPreviaDto | null>(null);
const motivo = ref("");
const pedirMotivo = ref(false);
const ocupado = ref("");
const erro = ref("");
const aviso = ref("");

const eventosAtivos = computed(() => eventos.value.filter((evento) => evento.ativo));
const unidadesDoEvento = computed(() => eventos.value.find((evento) => evento.id === novo.eventoId)?.unidades ?? []);
const opcoesColaborador = computed(() =>
  colaboradores.value
    .filter((item) => item.status === "ativo")
    .map((item) => ({ title: `${item.colaboradorNome} (${item.matricula})`, value: item.vinculoId }))
);
const opcoesEvento = computed(() =>
  eventosAtivos.value.map((evento) => ({ title: `${evento.codigo} — ${evento.descricao}`, value: evento.id }))
);

function falhou(falha: unknown, padrao: string) {
  erro.value = falha instanceof ErroApiCliente ? falha.message : padrao;
}

async function carregarLancamentos() {
  try {
    lancamentos.value = await apiGet<QuestorLancamentoVariavelDto[]>(
      `${ROTAS_EXPORTACAO_QUESTOR.lancamentos}?competencia=${competencia.value}`
    );
    selecionados.value = lancamentos.value.filter((item) => !item.exportado).map((item) => item.id);
  } catch (falha) {
    falhou(falha, "Lançamentos indisponíveis.");
  }
}

async function lancar() {
  const dados = questorEventosVariaveisLancamentoSchema.safeParse({
    ...novo,
    competencia: competencia.value,
    valor: novo.valor.replace(",", ".")
  });
  if (!dados.success) {
    erro.value = dados.error.issues[0]?.message ?? "Lançamento inválido.";
    return;
  }
  ocupado.value = "lancar";
  erro.value = "";
  try {
    await apiPost(ROTAS_EXPORTACAO_QUESTOR.lancamentos, dados.data);
    novo.valor = "";
    await carregarLancamentos();
  } catch (falha) {
    falhou(falha, "Não foi possível lançar.");
  } finally {
    ocupado.value = "";
  }
}

async function remover(item: QuestorLancamentoVariavelDto) {
  erro.value = "";
  try {
    await apiDelete(ROTAS_EXPORTACAO_QUESTOR.lancamento.replace(":id", item.id));
    await carregarLancamentos();
  } catch (falha) {
    falhou(falha, "Não foi possível remover.");
  }
}

async function conferir() {
  ocupado.value = "previa";
  erro.value = "";
  aviso.value = "";
  try {
    previa.value = await apiPost<QuestorEventosVariaveisPreviaDto>(ROTAS_EXPORTACAO_QUESTOR.eventosPrevia, {
      competencia: competencia.value,
      lancamentoIds: selecionados.value
    });
  } catch (falha) {
    falhou(falha, "Não foi possível montar a prévia.");
  } finally {
    ocupado.value = "";
  }
}

async function gerar() {
  ocupado.value = "gerar";
  erro.value = "";
  try {
    const arquivo = await baixar(ROTAS_EXPORTACAO_QUESTOR.eventosDownload, {
      competencia: competencia.value,
      lancamentoIds: selecionados.value,
      ...(pedirMotivo.value && motivo.value ? { motivoRegeracao: motivo.value } : {})
    });
    aviso.value = arquivo.reutilizado
      ? `${arquivo.nomeArquivo}: reaproveitado do histórico.`
      : `${arquivo.nomeArquivo} gerado.`;
    pedirMotivo.value = false;
    motivo.value = "";
    await carregarLancamentos();
    emit("gerado");
  } catch (falha) {
    if (falha instanceof ErroApiCliente && falha.codigo === ERROS_EXPORTACAO_QUESTOR.jaExportado)
      pedirMotivo.value = true;
    falhou(falha, "Não foi possível gerar o CSV.");
  } finally {
    ocupado.value = "";
  }
}

watch(mes, () => {
  previa.value = null;
  void carregarLancamentos();
});
watch(selecionados, () => (previa.value = null));
watch(unidadesDoEvento, (unidades) => (novo.unidade = unidades.length === 1 ? unidades[0]! : ""));
onMounted(async () => {
  await carregarLancamentos();
  try {
    colaboradores.value = await apiGet<ContratoColaboradorQuestorDto[]>(ROTAS_QUESTOR.contratosColaboradores);
  } catch (falha) {
    falhou(falha, "Lista de colaboradores indisponível.");
  }
});
</script>

<template>
  <v-card variant="outlined">
    <v-card-title>Eventos variáveis — CSV</v-card-title>
    <v-card-text class="eventos">
      <v-alert v-if="erro" type="error" variant="tonal">{{ erro }}</v-alert>
      <v-alert v-if="aviso" type="success" variant="tonal">{{ aviso }}</v-alert>
      <QuestorEventosCatalogo v-model="eventos" />

      <v-divider />
      <div class="eventos__form">
        <v-text-field v-model="mes" type="month" label="Competência" density="compact" hide-details />
        <v-autocomplete
          v-model="novo.vinculoId"
          :items="opcoesColaborador"
          label="Colaborador"
          density="compact"
          hide-details
        />
        <v-select v-model="novo.eventoId" :items="opcoesEvento" label="Evento" density="compact" hide-details />
        <v-select v-model="novo.unidade" :items="unidadesDoEvento" label="Letra" density="compact" hide-details />
        <v-text-field v-model="novo.valor" label="Valor" inputmode="decimal" density="compact" hide-details />
        <v-btn color="primary" variant="tonal" :loading="ocupado === 'lancar'" @click="lancar">Lançar</v-btn>
      </div>
      <p class="muted">Horas na convenção da empresa no Questor: com hora centesimal 1,50 = 1h30; sem, 1,30 = 1h30.</p>

      <div class="responsive-table-shell">
        <v-table density="compact">
          <thead>
            <tr>
              <th />
              <th>Colaborador</th>
              <th>Contrato Questor</th>
              <th>Evento</th>
              <th>Valor</th>
              <th />
            </tr>
          </thead>
          <tbody>
            <tr v-for="item in lancamentos" :key="item.id">
              <td>
                <v-checkbox-btn
                  v-model="selecionados"
                  :value="item.id"
                  :aria-label="`Selecionar ${item.colaboradorNome}`"
                />
              </td>
              <td>{{ item.colaboradorNome }}</td>
              <td>{{ item.questorCodigoContrato ?? "sem código" }}</td>
              <td>{{ item.eventoCodigo }} {{ item.unidade }}</td>
              <td>{{ formatarValorEventoVariavel(item.valor) }}</td>
              <td class="text-end">
                <v-chip v-if="item.exportado" size="x-small" color="success" variant="tonal">Exportado</v-chip>
                <v-btn
                  v-else
                  icon="mdi-delete-outline"
                  variant="text"
                  size="small"
                  :aria-label="`Remover lançamento de ${item.colaboradorNome}`"
                  @click="remover(item)"
                />
              </td>
            </tr>
            <tr v-if="!lancamentos.length">
              <td colspan="6" class="text-center muted">Nenhum lançamento nesta competência.</td>
            </tr>
          </tbody>
        </v-table>
      </div>

      <div class="eventos__acoes">
        <v-btn :disabled="!selecionados.length" :loading="ocupado === 'previa'" @click="conferir">Conferir CSV</v-btn>
        <v-btn
          color="primary"
          prepend-icon="mdi-file-delimited-outline"
          :disabled="!previa?.valido || !previa.exportacaoDisponivel"
          :loading="ocupado === 'gerar'"
          @click="gerar"
          >Gerar CSV oficial</v-btn
        >
      </div>
      <v-text-field
        v-if="pedirMotivo"
        v-model="motivo"
        label="Motivo para gerar de novo (o Questor duplica lançamento importado duas vezes)"
        maxlength="500"
        counter="500"
      />
      <div v-if="previa" class="eventos__previa">
        <v-alert v-if="previa.bloqueio" type="info" variant="tonal" density="compact">
          CSV oficial bloqueado até a homologação da Conplus. A prévia abaixo é o arquivo que seria gerado.
        </v-alert>
        <v-alert v-if="previa.jaExportados" type="warning" variant="tonal" density="compact">
          {{ previa.jaExportados }} lançamento(s) desta seleção já saíram em arquivo oficial.
        </v-alert>
        <ul v-if="previa.pendencias.length || previa.diagnosticos.length">
          <li v-for="item in [...previa.pendencias, ...previa.diagnosticos]" :key="item">{{ item }}</li>
        </ul>
        <pre v-if="previa.conteudo" class="eventos__csv">{{ previa.conteudo }}</pre>
      </div>
    </v-card-text>
  </v-card>
</template>

<style scoped>
.eventos {
  display: grid;
  gap: 12px;
}
.eventos__form {
  display: grid;
  grid-template-columns: 150px minmax(0, 1.4fr) minmax(0, 1.2fr) 90px 110px auto;
  gap: 8px;
  align-items: center;
}
.eventos__acoes {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}
.eventos__previa {
  display: grid;
  gap: 8px;
  overflow-wrap: anywhere;
}
.eventos__csv {
  margin: 0;
  padding: 12px;
  overflow-x: auto;
  border-radius: 8px;
  background: rgba(var(--v-theme-on-surface), 0.05);
  font-size: 0.8rem;
}
.muted {
  color: rgba(var(--v-theme-on-surface), 0.68);
  margin: 0;
}
@media (max-width: 1100px) {
  .eventos__form {
    grid-template-columns: 1fr 1fr 1fr;
  }
}
@media (max-width: 600px) {
  .eventos__form {
    grid-template-columns: 1fr;
  }
}
</style>
