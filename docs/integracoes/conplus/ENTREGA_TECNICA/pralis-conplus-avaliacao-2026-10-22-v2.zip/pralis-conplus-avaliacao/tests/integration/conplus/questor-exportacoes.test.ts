import { createHash } from "node:crypto";
import { readFile, rm, writeFile } from "node:fs/promises";
import { afterAll, afterEach, beforeAll, describe, expect, it } from "vitest";
import { permissoesPorCargo, regrasPermissoes } from "@padaria/db/referencia-permissoes";
import type { Permissao } from "@padaria/shared";
import {
  ERROS_EXPORTACAO_QUESTOR,
  ROTAS_EXPORTACAO_QUESTOR,
  ROTAS_QUESTOR,
  type QuestorEventosVariaveisPreviaDto,
  type QuestorExportacaoHistoricoDto,
  type QuestorExportacaoPreviaDto,
  type QuestorLancamentoVariavelDto
} from "@padaria/shared/conplus";
import { env } from "../../../api/src/env.js";
import { caminhoAbsolutoDocumento } from "../../../api/src/lancamentos/foto-documento.js";
import { criarContextoApiTeste, type ContextoApiTeste } from "../../setup/aplicacao.js";
import { cookieSessao } from "../../setup/auth.js";
import { idsTeste, usuariosTeste } from "../../setup/contexto.js";
import { consultarTodos, consultarUm, executarSql } from "../../setup/integracao.js";

/**
 * Fluxo completo das exportações Questor pela rota HTTP real, com dados FICTÍCIOS:
 * colaborador → contrato Questor → lançamentos → prévia → geração → auditoria → histórico → download,
 * e o TXT de admissão (técnico e oficial). Os gates de homologação são ligados SÓ dentro dos testes
 * que exercitam o caminho oficial e desligados em seguida.
 */
describe("exportações Questor — fluxo completo", () => {
  let contexto: ContextoApiTeste;
  let cookieDp: string;
  let cookieGerencia: string;
  let usuarioId: string;

  const ids = {
    turnoA: "11111111-1111-4111-8111-11111111e701",
    turnoB: "11111111-1111-4111-8111-11111111e702",
    funcaoB: "11111111-1111-4111-8111-11111111e703",
    processoTxt: "11111111-1111-4111-8111-11111111e704",
    processoB: "11111111-1111-4111-8111-11111111e705",
    processoV1: "11111111-1111-4111-8111-11111111e706",
    processoV2: "11111111-1111-4111-8111-11111111e707",
    processoVB: "11111111-1111-4111-8111-11111111e708",
    colaborador1: "11111111-1111-4111-8111-11111111e709",
    colaborador2: "11111111-1111-4111-8111-11111111e70a",
    colaboradorB: "11111111-1111-4111-8111-11111111e70b",
    vinculo1: "11111111-1111-4111-8111-11111111e70c",
    vinculo2: "11111111-1111-4111-8111-11111111e70d",
    vinculoB: "11111111-1111-4111-8111-11111111e70e",
    exportacaoB: "11111111-1111-4111-8111-11111111e70f"
  };
  const competencia = "2026-10-01";
  const sha = (dados: string | Buffer) => createHash("sha256").update(dados).digest("hex");
  const arquivoUrl = (id: string) => ROTAS_EXPORTACAO_QUESTOR.arquivo.replace(":id", id);

  async function vestir(email: string, cargo: "DP" | "Gerencia") {
    const alvo = await consultarUm<{ id: string }>(`select id from "user" where email = $1`, [email]);
    if (!alvo) throw new Error(`usuário ${email} ausente`);
    await executarSql(
      `insert into permissoes_usuarios (usuario_id, regras) values ($1, $2::jsonb)
       on conflict (usuario_id) do update set regras = excluded.regras`,
      [alvo.id, JSON.stringify(regrasPermissoes(permissoesPorCargo[cargo] as Permissao[]))]
    );
  }

  const chamar = (
    method: "GET" | "POST" | "PATCH" | "DELETE" | "PUT",
    url: string,
    payload?: object,
    cookie = cookieDp
  ) => contexto.app.inject({ method, url, headers: { cookie }, ...(payload ? { payload } : {}) });

  async function processoAprovado(id: string, empresaId: string, turnoId: string, funcaoId: string, cpf: string) {
    await executarSql(
      `insert into admissoes_processos
         (id, empresa_id, origem, teste_id, nome_completo, cpf, funcao_id, turno_id, criado_por, atualizado_por)
       values ($1, $2, 'admissao_direta', null, 'Pessoa Ficticia Exportacao', $3, $4, $5, $6, $6) on conflict do nothing`,
      [id, empresaId, cpf, funcaoId, turnoId, usuarioId]
    );
    await executarSql(
      `insert into admissoes_processos_internos (empresa_id, processo_id, data_admissao, ctps_numero, ctps_serie, ctps_uf, pis_pasep_nit)
       values ($1, $2, '2026-10-01', '1234567', '0001', 'MG', '12345678901') on conflict do nothing`,
      [empresaId, id]
    );
    await executarSql(
      `insert into admissoes_processos_ficha
         (empresa_id, processo_id, situacao, versao, nascimento, sexo, estado_civil, raca_cor, nacionalidade, nome_mae,
          cep, logradouro, numero, bairro, municipio, uf, telefone, sem_dependentes,
          enviado_em, revisado_em, revisado_por, aviso_aceito_em, aviso_privacidade_versao)
       values ($1, $2, 'aprovada', 3, '1998-02-02', 'Feminino', 'Solteira', 'Parda', 'Brasileira', 'Mae Ficticia',
          '36037467', 'Rua Ficticia', '100', 'Centro', 'Cidade Ficticia', 'MG', '32999990000', true,
          now(), now(), $3, now(), 'v1')
       on conflict do nothing`,
      [empresaId, id, usuarioId]
    );
  }

  async function vinculo(p: {
    processo: string;
    colaborador: string;
    vinculo: string;
    empresaId: string;
    funcaoId: string;
    turnoId: string;
    nome: string;
    numero: number;
    cpf: string;
    codigo: string | null;
  }) {
    await executarSql(
      `insert into admissoes_processos
         (id, empresa_id, origem, teste_id, nome_completo, cpf, funcao_id, turno_id, criado_por, atualizado_por)
       values ($1, $2, 'admissao_direta', null, $3, $4, $5, $6, $7, $7) on conflict do nothing`,
      [p.processo, p.empresaId, p.nome, p.cpf, p.funcaoId, p.turnoId, usuarioId]
    );
    await executarSql(`insert into colaboradores (id, empresa_id, nome) values ($1, $2, $3) on conflict do nothing`, [
      p.colaborador,
      p.empresaId,
      p.nome
    ]);
    await executarSql(
      `insert into colaboradores_vinculos
         (id, empresa_id, colaborador_id, processo_id, numero_sequencial, matricula, admitido_em,
          funcao_id, funcao_nome, jornada_horario, criado_por, questor_codigo_contrato)
       values ($1, $2, $3, $4, $5, $6, '2026-09-01', $7, 'Funcao Ficticia', '06:00-14:00', $8, $9) on conflict do nothing`,
      [
        p.vinculo,
        p.empresaId,
        p.colaborador,
        p.processo,
        p.numero,
        `EXP-${String(p.numero).padStart(6, "0")}`,
        p.funcaoId,
        usuarioId,
        p.codigo
      ]
    );
  }

  function ligarGates(ligados: boolean) {
    (env as { CONPLUS_QUESTOR_EXPORT_ENABLED: boolean }).CONPLUS_QUESTOR_EXPORT_ENABLED = ligados;
    (env as { CONPLUS_QUESTOR_EXPORT_HOMOLOGADA: boolean }).CONPLUS_QUESTOR_EXPORT_HOMOLOGADA = ligados;
  }

  const exportacoesDaEmpresa = () =>
    consultarTodos<{
      id: string;
      tipo: string;
      resultado: string;
      caminho_arquivo: string | null;
      sha256: string;
      motivo_regeracao: string | null;
    }>(
      `select id, tipo, resultado, caminho_arquivo, sha256, motivo_regeracao from questor_exportacoes
        where empresa_id = $1 order by criado_em`,
      [idsTeste.empresaA]
    );

  beforeAll(async () => {
    contexto = await criarContextoApiTeste();
    await vestir(usuariosTeste.caixa.email, "DP");
    await vestir(usuariosTeste.gerente.email, "Gerencia");
    cookieDp = await cookieSessao(contexto.app, "caixa");
    cookieGerencia = await cookieSessao(contexto.app, "gerente");
    usuarioId = (await consultarUm<{ usuario_id: string }>("select usuario_id from perfis_usuarios limit 1"))!
      .usuario_id;

    for (const [turno, empresa] of [
      [ids.turnoA, idsTeste.empresaA],
      [ids.turnoB, idsTeste.empresaB]
    ] as const) {
      await executarSql(
        `insert into turnos (id, empresa_id, nome, hora_inicio, hora_fim, etiqueta, dias_semana)
         values ($1, $2, 'Turno Exportacao', '06:00', '14:00', 'M', array['SEGUNDA']::text[]) on conflict do nothing`,
        [turno, empresa]
      );
    }
    await executarSql(
      `insert into funcoes_operacionais (id, empresa_id, nome) values ($1, $2, 'Funcao Exportacao B') on conflict do nothing`,
      [ids.funcaoB, idsTeste.empresaB]
    );
    await processoAprovado(ids.processoTxt, idsTeste.empresaA, ids.turnoA, idsTeste.funcaoOperacionalA, "98765432100");
    await processoAprovado(ids.processoB, idsTeste.empresaB, ids.turnoB, ids.funcaoB, "39053344705");

    const baseA = { empresaId: idsTeste.empresaA, funcaoId: idsTeste.funcaoOperacionalA, turnoId: ids.turnoA };
    await vinculo({
      ...baseA,
      processo: ids.processoV1,
      colaborador: ids.colaborador1,
      vinculo: ids.vinculo1,
      nome: "Ana Ficticia",
      numero: 970001,
      cpf: "52998224725",
      codigo: "120"
    });
    await vinculo({
      ...baseA,
      processo: ids.processoV2,
      colaborador: ids.colaborador2,
      vinculo: ids.vinculo2,
      nome: "Bruno Ficticio",
      numero: 970002,
      cpf: "11144477735",
      codigo: null
    });
    await vinculo({
      empresaId: idsTeste.empresaB,
      funcaoId: ids.funcaoB,
      turnoId: ids.turnoB,
      processo: ids.processoVB,
      colaborador: ids.colaboradorB,
      vinculo: ids.vinculoB,
      nome: "Carla Ficticia",
      numero: 970003,
      cpf: "86288366757",
      codigo: "120"
    });

    await executarSql(
      `insert into questor_exportacoes (id, empresa_id, tipo, layout_versao, sha256, chave_idempotencia, resultado, nome_arquivo, caminho_arquivo, gerado_por)
       values ($1, $2, 'admissao', 'questor-admissao-v2', $3, 'previa:outra-empresa', 'previa', 'outra.txt', 'questor-exportacoes/x/y.txt', $4)`,
      [ids.exportacaoB, idsTeste.empresaB, "f".repeat(64), usuarioId]
    );
  }, 180_000);

  afterEach(() => ligarGates(false));

  afterAll(async () => {
    ligarGates(false);
    const empresas = [idsTeste.empresaA, idsTeste.empresaB];
    await executarSql("delete from questor_exportacoes_eventos_variaveis where empresa_id = any($1::uuid[])", [
      empresas
    ]);
    await executarSql("delete from questor_exportacoes_admissoes where empresa_id = any($1::uuid[])", [empresas]);
    await executarSql("delete from questor_exportacoes where empresa_id = any($1::uuid[])", [empresas]);
    await executarSql("delete from questor_eventos_variaveis_lancamentos where empresa_id = any($1::uuid[])", [
      empresas
    ]);
    await executarSql("delete from questor_eventos_variaveis where empresa_id = any($1::uuid[])", [empresas]);
    await executarSql("delete from questor_configuracoes where empresa_id = any($1::uuid[])", [empresas]);
    await executarSql("delete from colaboradores_vinculos where id = any($1::uuid[])", [
      [ids.vinculo1, ids.vinculo2, ids.vinculoB]
    ]);
    await executarSql("delete from colaboradores where id = any($1::uuid[])", [
      [ids.colaborador1, ids.colaborador2, ids.colaboradorB]
    ]);
    await executarSql("delete from admissoes_processos where id = any($1::uuid[])", [
      [ids.processoTxt, ids.processoB, ids.processoV1, ids.processoV2, ids.processoVB]
    ]);
    await executarSql("delete from turnos where id = any($1::uuid[])", [[ids.turnoA, ids.turnoB]]);
    await executarSql("delete from funcoes_operacionais where id = $1", [ids.funcaoB]);
    // Só a pasta das empresas FICTÍCIAS da suíte: o storage real nunca é tocado.
    for (const empresa of empresas) {
      await rm(caminhoAbsolutoDocumento(`questor-exportacoes/${empresa}`), { recursive: true, force: true });
    }
    await contexto.fechar();
  });

  // --- TXT de admissão --------------------------------------------------------------------------------

  describe("TXT de admissão", () => {
    let exportacaoTecnicaId = "";

    it("prévia: mostra pendências oficiais, avisa o bloqueio e não grava nada", async () => {
      const resposta = await chamar("POST", ROTAS_EXPORTACAO_QUESTOR.admissoesPrevia, {
        processoIds: [ids.processoTxt]
      });
      expect(resposta.statusCode, resposta.body).toBe(200);
      const previa = resposta.json().data as QuestorExportacaoPreviaDto;
      expect(previa).toMatchObject({ exportacaoDisponivel: false, bloqueio: ERROS_EXPORTACAO_QUESTOR.naoHomologada });
      expect(previa.registros[0]).toMatchObject({
        processoId: ids.processoTxt,
        fichaAprovada: true,
        situacao: "bloqueado"
      });
      expect(previa.registros[0]!.quantidadeLinhas).toBe(3);
      expect(previa.registros[0]!.diagnosticos).toContain("A.CATEGORIA: CATEGORIA é requerido pela documentação");
      expect(await exportacoesDaEmpresa()).toHaveLength(0);
    });

    it("arquivo técnico: TXT A/B/C com CRLF, nome NÃO-IMPORTAR, SHA no cabeçalho, auditoria e arquivo no storage", async () => {
      const resposta = await chamar("POST", ROTAS_EXPORTACAO_QUESTOR.admissoesTecnico, {
        processoIds: [ids.processoTxt]
      });
      expect(resposta.statusCode, resposta.body).toBe(200);
      expect(resposta.headers["content-type"]).toBe("text/plain; charset=utf-8");
      expect(resposta.headers["content-disposition"]).toMatch(
        /^attachment; filename="TECNICO-NAO-IMPORTAR-admissao-questor-[0-9a-f]{12}\.txt"$/u
      );
      expect(resposta.headers["x-questor-sha256"]).toBe(sha(resposta.rawPayload));
      expect(resposta.headers["x-questor-reutilizado"]).toBe("false");
      const linhas = resposta.body.split("\r\n");
      expect(linhas.slice(0, 3).map((linha) => linha.split(";")[0])).toEqual(["A", "B", "C"]);
      expect(linhas.at(-1)).toBe("");
      expect(resposta.body).not.toMatch(/[^\r]\n/u);

      const [registro] = await exportacoesDaEmpresa();
      expect(registro).toMatchObject({ tipo: "admissao", resultado: "previa", sha256: sha(resposta.rawPayload) });
      exportacaoTecnicaId = registro!.id;
      expect(resposta.headers["x-questor-exportacao-id"]).toBe(exportacaoTecnicaId);
      const vinculos = await consultarTodos(
        "select processo_id from questor_exportacoes_admissoes where exportacao_id = $1",
        [exportacaoTecnicaId]
      );
      expect(vinculos).toEqual([{ processo_id: ids.processoTxt }]);
      expect(await readFile(caminhoAbsolutoDocumento(registro!.caminho_arquivo!))).toEqual(resposta.rawPayload);
    });

    it("idempotência: o mesmo conteúdo devolve o registro existente, sem nova linha de auditoria", async () => {
      const resposta = await chamar("POST", ROTAS_EXPORTACAO_QUESTOR.admissoesTecnico, {
        processoIds: [ids.processoTxt]
      });
      expect(resposta.statusCode).toBe(200);
      expect(resposta.headers["x-questor-reutilizado"]).toBe("true");
      expect(resposta.headers["x-questor-exportacao-id"]).toBe(exportacaoTecnicaId);
      expect(await exportacoesDaEmpresa()).toHaveLength(1);
    });

    it("histórico + novo download: mesmos bytes e SHA conferido contra a auditoria", async () => {
      const historico = await chamar("GET", `${ROTAS_EXPORTACAO_QUESTOR.historico}?tipo=admissao`);
      expect(historico.statusCode).toBe(200);
      const itens = historico.json().data as QuestorExportacaoHistoricoDto[];
      expect(itens.find((item) => item.id === exportacaoTecnicaId)).toMatchObject({
        resultado: "previa",
        temArquivo: true,
        geradoPorNome: expect.any(String)
      });
      expect(itens.some((item) => item.id === ids.exportacaoB)).toBe(false);

      const download = await chamar("GET", arquivoUrl(exportacaoTecnicaId));
      expect(download.statusCode).toBe(200);
      expect(download.headers["x-questor-sha256"]).toBe(sha(download.rawPayload));
      expect(download.headers["content-disposition"]).toContain("TECNICO-NAO-IMPORTAR-");
    });

    it("oficial com gates desligados: 422 de homologação e nada gravado", async () => {
      const resposta = await chamar("POST", ROTAS_EXPORTACAO_QUESTOR.admissoesDownload, {
        processoIds: [ids.processoTxt]
      });
      expect(resposta.statusCode).toBe(422);
      expect(resposta.json().code).toBe(ERROS_EXPORTACAO_QUESTOR.naoHomologada);
      expect(await exportacoesDaEmpresa()).toHaveLength(1);
    });

    it("oficial com gates ligados e pendências: 422 inválida e tentativa registrada como bloqueada, sem arquivo", async () => {
      ligarGates(true);
      const resposta = await chamar("POST", ROTAS_EXPORTACAO_QUESTOR.admissoesDownload, {
        processoIds: [ids.processoTxt]
      });
      expect(resposta.statusCode).toBe(422);
      expect(resposta.json().code).toBe(ERROS_EXPORTACAO_QUESTOR.invalida);
      const bloqueada = (await exportacoesDaEmpresa()).find((item) => item.resultado === "bloqueado");
      expect(bloqueada).toMatchObject({ tipo: "admissao", caminho_arquivo: null });
      const semArquivo = await chamar("GET", arquivoUrl(bloqueada!.id));
      expect(semArquivo.statusCode).toBe(404);
      expect(semArquivo.json().code).toBe(ERROS_EXPORTACAO_QUESTOR.arquivoAusente);
    });

    it("dados inválidos e outra empresa: ids repetidos 400, processo de outra empresa 422, arquivo de outra empresa 404", async () => {
      const repetido = await chamar("POST", ROTAS_EXPORTACAO_QUESTOR.admissoesTecnico, {
        processoIds: [ids.processoTxt, ids.processoTxt]
      });
      expect(repetido.statusCode).toBe(400);
      const outraEmpresa = await chamar("POST", ROTAS_EXPORTACAO_QUESTOR.admissoesTecnico, {
        processoIds: [ids.processoB]
      });
      expect(outraEmpresa.statusCode).toBe(422);
      expect(outraEmpresa.json().code).toBe(ERROS_EXPORTACAO_QUESTOR.processoNaoExportavel);
      expect((await chamar("GET", arquivoUrl(ids.exportacaoB))).statusCode).toBe(404);
      expect((await chamar("GET", arquivoUrl("nao-e-uuid"))).statusCode).toBe(400);
      const comEmpresa = await chamar("POST", ROTAS_EXPORTACAO_QUESTOR.admissoesTecnico, {
        processoIds: [ids.processoTxt],
        empresaId: idsTeste.empresaB
      });
      expect(comEmpresa.statusCode).toBe(400);
    });

    it("arquivo apagado do storage responde 404; arquivo adulterado responde 409", async () => {
      const [registro] = await exportacoesDaEmpresa();
      const caminho = caminhoAbsolutoDocumento(registro!.caminho_arquivo!);
      const original = await readFile(caminho);
      await writeFile(caminho, "adulterado");
      const adulterado = await chamar("GET", arquivoUrl(registro!.id));
      expect(adulterado.statusCode).toBe(409);
      await rm(caminho);
      const apagado = await chamar("GET", arquivoUrl(registro!.id));
      expect(apagado.statusCode).toBe(404);
      await writeFile(caminho, original);
    });

    it("permissões: Gerência 403 em todas as rotas; sem sessão 401", async () => {
      for (const [metodo, url] of [
        ["POST", ROTAS_EXPORTACAO_QUESTOR.admissoesPrevia],
        ["POST", ROTAS_EXPORTACAO_QUESTOR.admissoesTecnico],
        ["POST", ROTAS_EXPORTACAO_QUESTOR.admissoesDownload],
        ["GET", ROTAS_EXPORTACAO_QUESTOR.historico],
        ["GET", arquivoUrl(exportacaoTecnicaId)]
      ] as const) {
        const resposta = await chamar(
          metodo,
          url,
          metodo === "POST" ? { processoIds: [ids.processoTxt] } : undefined,
          cookieGerencia
        );
        expect(resposta.statusCode, `${metodo} ${url}`).toBe(403);
        const anonimo = await contexto.app.inject({
          method: metodo,
          url,
          ...(metodo === "POST" ? { payload: { processoIds: [ids.processoTxt] } } : {})
        });
        expect(anonimo.statusCode, `${metodo} ${url}`).toBe(401);
      }
    });
  });

  // --- CSV de eventos variáveis -----------------------------------------------------------------------

  describe("CSV de eventos variáveis", () => {
    let eventoHoras = "";
    let eventoValor = "";
    let lancamentos: QuestorLancamentoVariavelDto[] = [];

    it("catálogo: cria, recusa duplicado e unidade inválida, desativa e reativa", async () => {
      const horas = await chamar("POST", ROTAS_EXPORTACAO_QUESTOR.eventos, {
        codigo: "901",
        descricao: "Hora extra ficticia",
        unidades: ["H"]
      });
      expect(horas.statusCode, horas.body).toBe(201);
      eventoHoras = horas.json().data.id;
      const valor = await chamar("POST", ROTAS_EXPORTACAO_QUESTOR.eventos, {
        codigo: "902",
        descricao: "Premio ficticio",
        unidades: ["V"]
      });
      eventoValor = valor.json().data.id;
      expect(
        (await chamar("POST", ROTAS_EXPORTACAO_QUESTOR.eventos, { codigo: "901", descricao: "x", unidades: ["H"] }))
          .statusCode
      ).toBe(409);
      expect(
        (await chamar("POST", ROTAS_EXPORTACAO_QUESTOR.eventos, { codigo: "903", descricao: "x", unidades: ["X"] }))
          .statusCode
      ).toBe(400);
      expect(
        (await chamar("POST", ROTAS_EXPORTACAO_QUESTOR.eventos, { codigo: "903", descricao: "a;b", unidades: ["V"] }))
          .statusCode
      ).toBe(400);

      const evento = ROTAS_EXPORTACAO_QUESTOR.evento.replace(":id", eventoValor);
      expect((await chamar("PATCH", evento, { ativo: false })).json().data.ativo).toBe(false);
      const inativo = await chamar("POST", ROTAS_EXPORTACAO_QUESTOR.lancamentos, {
        competencia,
        vinculoId: ids.vinculo1,
        eventoId: eventoValor,
        unidade: "V",
        valor: "150"
      });
      expect(inativo.statusCode).toBe(422);
      expect((await chamar("PATCH", evento, { ativo: true })).json().data.ativo).toBe(true);
    });

    it("lançamentos: valida competência, unidade, valor, duplicidade e empresa", async () => {
      const lancar = (corpo: object) =>
        chamar("POST", ROTAS_EXPORTACAO_QUESTOR.lancamentos, { competencia, unidade: "H", ...corpo });
      expect((await lancar({ vinculoId: ids.vinculo1, eventoId: eventoHoras, valor: "1.30" })).statusCode).toBe(201);
      expect(
        (await lancar({ vinculoId: ids.vinculo1, eventoId: eventoValor, unidade: "V", valor: "150.5" })).statusCode
      ).toBe(201);
      expect((await lancar({ vinculoId: ids.vinculo2, eventoId: eventoHoras, valor: "2" })).statusCode).toBe(201);

      expect((await lancar({ vinculoId: ids.vinculo1, eventoId: eventoHoras, valor: "3" })).statusCode).toBe(409);
      expect((await lancar({ vinculoId: ids.vinculo1, eventoId: eventoValor, valor: "1" })).statusCode).toBe(422);
      expect((await lancar({ vinculoId: ids.vinculoB, eventoId: eventoHoras, valor: "1" })).statusCode).toBe(404);
      for (const invalido of [
        { vinculoId: ids.vinculo1, eventoId: eventoHoras, valor: "1,30" },
        { vinculoId: ids.vinculo1, eventoId: eventoHoras, valor: "0" },
        { vinculoId: ids.vinculo1, eventoId: eventoHoras, valor: "1", competencia: "2026-10-15" }
      ]) {
        expect((await lancar(invalido)).statusCode, JSON.stringify(invalido)).toBe(400);
      }

      const lista = await chamar("GET", `${ROTAS_EXPORTACAO_QUESTOR.lancamentos}?competencia=${competencia}`);
      lancamentos = lista.json().data as QuestorLancamentoVariavelDto[];
      expect(lancamentos.map((item) => [item.colaboradorNome, item.eventoCodigo, item.valor])).toEqual([
        ["Ana Ficticia", "901", "1.3000"],
        ["Ana Ficticia", "902", "150.5000"],
        ["Bruno Ficticio", "901", "2.0000"]
      ]);
      expect(lancamentos.every((item) => item.exportado === false)).toBe(true);
    });

    it("prévia: aponta hora centesimal não configurada e colaborador sem código de contrato", async () => {
      const resposta = await chamar("POST", ROTAS_EXPORTACAO_QUESTOR.eventosPrevia, {
        competencia,
        lancamentoIds: lancamentos.map((item) => item.id)
      });
      expect(resposta.statusCode, resposta.body).toBe(200);
      const previa = resposta.json().data as QuestorEventosVariaveisPreviaDto;
      expect(previa.valido).toBe(false);
      expect(previa.conteudo).toBe("");
      expect(previa.pendencias).toEqual(
        expect.arrayContaining([
          expect.stringContaining("Hora Centesimal"),
          expect.stringContaining("Bruno Ficticio (EXP-970002): sem código de contrato")
        ])
      );
    });

    it("prévia válida depois de configurar a empresa e informar o contrato pela tela do DP", async () => {
      await executarSql(
        `insert into questor_configuracoes (empresa_id, utiliza_hora_centesimal) values ($1, false)
         on conflict (empresa_id) do update set utiliza_hora_centesimal = false`,
        [idsTeste.empresaA]
      );
      const contratos = await chamar("GET", ROTAS_QUESTOR.contratosColaboradores);
      const bruno = (contratos.json().data as Array<{ vinculoId: string; atualizadoEm: string }>).find(
        (item) => item.vinculoId === ids.vinculo2
      )!;
      const salvo = await chamar("PUT", ROTAS_QUESTOR.contratoColaborador.replace(":id", ids.vinculo2), {
        questorCodigoContrato: "45",
        atualizadoEmLido: bruno.atualizadoEm
      });
      expect(salvo.statusCode, salvo.body).toBe(200);

      const resposta = await chamar("POST", ROTAS_EXPORTACAO_QUESTOR.eventosPrevia, {
        competencia,
        lancamentoIds: lancamentos.map((item) => item.id)
      });
      const previa = resposta.json().data as QuestorEventosVariaveisPreviaDto;
      expect(previa).toMatchObject({
        valido: true,
        pendencias: [],
        diagnosticos: [],
        quantidadeEmpregados: 2,
        exportacaoDisponivel: false
      });
      expect(previa.conteudo).toBe(
        [
          ";;901;902",
          ";;H;V",
          "Empregado;Nome;Hora extra ficticia;Premio ficticio",
          "45;Bruno Ficticio;2,00;",
          "120;Ana Ficticia;1,30;150,50",
          ""
        ].join("\r\n")
      );
    });

    it("geração oficial: bloqueada sem gates; com gates gera CSV, auditoria, vínculos e histórico; repetir é idempotente", async () => {
      const corpo = { competencia, lancamentoIds: lancamentos.map((item) => item.id) };
      const bloqueada = await chamar("POST", ROTAS_EXPORTACAO_QUESTOR.eventosDownload, corpo);
      expect(bloqueada.statusCode).toBe(422);
      expect(bloqueada.json().code).toBe(ERROS_EXPORTACAO_QUESTOR.naoHomologada);

      ligarGates(true);
      const gerada = await chamar("POST", ROTAS_EXPORTACAO_QUESTOR.eventosDownload, corpo);
      expect(gerada.statusCode, gerada.body).toBe(200);
      expect(gerada.headers["content-type"]).toBe("text/csv; charset=utf-8");
      expect(gerada.headers["content-disposition"]).toMatch(/filename="eventos-variaveis-2026-10-[0-9a-f]{12}\.csv"/u);
      expect(gerada.headers["x-questor-sha256"]).toBe(sha(gerada.rawPayload));
      const id = gerada.headers["x-questor-exportacao-id"] as string;
      const registro = await consultarUm<{ resultado: string; competencia: string }>(
        "select resultado, competencia::text from questor_exportacoes where id = $1",
        [id]
      );
      expect(registro).toEqual({ resultado: "gerado", competencia });
      const vinculados = await consultarUm<{ n: number }>(
        "select count(*)::int n from questor_exportacoes_eventos_variaveis where exportacao_id = $1",
        [id]
      );
      expect(vinculados?.n).toBe(3);

      const repetida = await chamar("POST", ROTAS_EXPORTACAO_QUESTOR.eventosDownload, corpo);
      expect(repetida.headers["x-questor-reutilizado"]).toBe("true");
      expect(repetida.headers["x-questor-exportacao-id"]).toBe(id);

      const download = await chamar("GET", arquivoUrl(id));
      expect(download.rawPayload).toEqual(gerada.rawPayload);
      expect(download.headers["content-type"]).toBe("text/csv; charset=utf-8");
      const lista = await chamar("GET", `${ROTAS_EXPORTACAO_QUESTOR.lancamentos}?competencia=${competencia}`);
      expect((lista.json().data as QuestorLancamentoVariavelDto[]).every((item) => item.exportado)).toBe(true);
    });

    it("reexportar lançamento já exportado exige motivo; com motivo, gera e registra", async () => {
      ligarGates(true);
      const corpo = { competencia, lancamentoIds: [lancamentos[0]!.id] };
      const semMotivo = await chamar("POST", ROTAS_EXPORTACAO_QUESTOR.eventosDownload, corpo);
      expect(semMotivo.statusCode).toBe(409);
      expect(semMotivo.json().code).toBe(ERROS_EXPORTACAO_QUESTOR.jaExportado);
      const comMotivo = await chamar("POST", ROTAS_EXPORTACAO_QUESTOR.eventosDownload, {
        ...corpo,
        motivoRegeracao: "Questor rejeitou o arquivo anterior"
      });
      expect(comMotivo.statusCode, comMotivo.body).toBe(200);
      const registro = await consultarUm<{ motivo_regeracao: string }>(
        "select motivo_regeracao from questor_exportacoes where id = $1",
        [comMotivo.headers["x-questor-exportacao-id"]]
      );
      expect(registro?.motivo_regeracao).toBe("Questor rejeitou o arquivo anterior");
    });

    it("lançamento exportado não pode ser apagado; o não exportado pode", async () => {
      const exportado = await chamar("DELETE", ROTAS_EXPORTACAO_QUESTOR.lancamento.replace(":id", lancamentos[0]!.id));
      expect(exportado.statusCode).toBe(409);
      const novo = await chamar("POST", ROTAS_EXPORTACAO_QUESTOR.lancamentos, {
        competencia: "2026-11-01",
        vinculoId: ids.vinculo1,
        eventoId: eventoValor,
        unidade: "V",
        valor: "10"
      });
      expect(novo.statusCode).toBe(201);
      const apagado = await chamar("DELETE", ROTAS_EXPORTACAO_QUESTOR.lancamento.replace(":id", novo.json().data.id));
      expect(apagado.statusCode).toBe(204);
      expect(
        (await chamar("DELETE", ROTAS_EXPORTACAO_QUESTOR.lancamento.replace(":id", novo.json().data.id))).statusCode
      ).toBe(404);
    });

    it("isolamento e permissões: lançamento de outra empresa 404; Gerência 403", async () => {
      const outro = await consultarUm<{ id: string }>(
        `insert into questor_eventos_variaveis (empresa_id, codigo, descricao, unidades, criado_por)
         values ($1, '901', 'Evento B', array['H'], $2) returning id`,
        [idsTeste.empresaB, usuarioId]
      );
      const lancamentoB = await consultarUm<{ id: string }>(
        `insert into questor_eventos_variaveis_lancamentos (empresa_id, competencia, vinculo_id, evento_id, unidade, valor, criado_por)
         values ($1, $2, $3, $4, 'H', 1, $5) returning id`,
        [idsTeste.empresaB, competencia, ids.vinculoB, outro!.id, usuarioId]
      );
      const previa = await chamar("POST", ROTAS_EXPORTACAO_QUESTOR.eventosPrevia, {
        competencia,
        lancamentoIds: [lancamentos[0]!.id, lancamentoB!.id]
      });
      expect(previa.statusCode).toBe(404);
      expect(
        (await chamar("DELETE", ROTAS_EXPORTACAO_QUESTOR.lancamento.replace(":id", lancamentoB!.id))).statusCode
      ).toBe(404);
      for (const [metodo, url] of [
        ["GET", ROTAS_EXPORTACAO_QUESTOR.eventos],
        ["GET", ROTAS_EXPORTACAO_QUESTOR.lancamentos],
        ["POST", ROTAS_EXPORTACAO_QUESTOR.eventosPrevia],
        ["POST", ROTAS_EXPORTACAO_QUESTOR.eventosDownload]
      ] as const) {
        const resposta = await chamar(
          metodo,
          url,
          metodo === "POST" ? { competencia, lancamentoIds: [lancamentos[0]!.id] } : undefined,
          cookieGerencia
        );
        expect(resposta.statusCode, url).toBe(403);
      }
    });
  });
});
