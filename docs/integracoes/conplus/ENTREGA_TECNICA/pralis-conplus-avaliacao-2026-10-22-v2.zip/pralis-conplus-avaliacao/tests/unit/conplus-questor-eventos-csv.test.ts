import { describe, expect, it } from "vitest";
import {
  formatarValorEventoVariavel,
  lerCsvEventosVariaveis,
  prepararCsvEventosVariaveis,
  questorEventosVariaveisGeracaoSchema,
  questorEventosVariaveisLancamentoSchema,
  type LancamentoParaCsvQuestor
} from "../../shared/src/conplus/index.js";

const base: LancamentoParaCsvQuestor = {
  id: "l1",
  competencia: "2026-10-01",
  colaboradorNome: "Ana Ficticia",
  matricula: "EXP-000001",
  questorCodigoContrato: "120",
  eventoCodigo: "901",
  eventoDescricao: "Hora extra",
  eventoAtivo: true,
  eventoUnidades: ["H"],
  unidade: "H",
  valor: "1.3000"
};

describe("CSV de eventos variáveis a partir dos lançamentos", () => {
  it("valor do banco vira vírgula decimal com ao menos 2 casas, sem zeros sobrando", () => {
    expect(formatarValorEventoVariavel("1.3000")).toBe("1,30");
    expect(formatarValorEventoVariavel("150.0000")).toBe("150,00");
    expect(formatarValorEventoVariavel("12.3456")).toBe("12,3456");
    expect(formatarValorEventoVariavel("0007.5")).toBe("7,50");
    expect(formatarValorEventoVariavel("8")).toBe("8,00");
  });

  it("agrupa por contrato e por evento+letra, ordena e relê com o leitor oficial", () => {
    const lancamentos: LancamentoParaCsvQuestor[] = [
      base,
      {
        ...base,
        id: "l2",
        eventoCodigo: "15",
        eventoDescricao: "Premio",
        eventoUnidades: ["V", "R"],
        unidade: "V",
        valor: "99.9"
      },
      {
        ...base,
        id: "l3",
        colaboradorNome: "Bruno; Ficticio",
        matricula: "EXP-000002",
        questorCodigoContrato: "7",
        valor: "2"
      }
    ];
    const csv = prepararCsvEventosVariaveis("2026-10-01", lancamentos, false);
    expect(csv).toMatchObject({ valido: true, pendencias: [], quantidadeEmpregados: 2 });
    expect(csv.conteudo.split("\r\n")).toEqual([
      ";;15;901",
      ";;V;H",
      "Empregado;Nome;Premio;Hora extra",
      "7;Bruno Ficticio;;2,00",
      "120;Ana Ficticia;99,90;1,30",
      ""
    ]);
    const relido = lerCsvEventosVariaveis(csv.conteudo, { utilizaHoraCentesimal: false });
    expect(relido.diagnosticos).toEqual([]);
    expect(relido.linhas.map((linha) => linha.codigoEmpregado)).toEqual(["7", "120"]);
  });

  it("pendências do Pralís bloqueiam o arquivo e dizem quem resolve", () => {
    const csv = prepararCsvEventosVariaveis(
      "2026-10-01",
      [
        { ...base, questorCodigoContrato: null },
        { ...base, id: "l2", competencia: "2026-09-01", matricula: "EXP-000003", questorCodigoContrato: "8" },
        { ...base, id: "l3", eventoAtivo: false, matricula: "EXP-000004", questorCodigoContrato: "9" },
        { ...base, id: "l4", eventoUnidades: ["V"], matricula: "EXP-000005", questorCodigoContrato: "10" }
      ],
      null
    );
    expect(csv.valido).toBe(false);
    expect(csv.conteudo).toBe("");
    expect(csv.pendencias).toEqual([
      'Configure "Utiliza Hora Centesimal" da empresa em Configuração Questor',
      "Ana Ficticia (EXP-000001): sem código de contrato Questor (Configuração Questor → Contratos no Questor)",
      "Ana Ficticia (EXP-000003): lançamento de outra competência (2026-09-01)",
      "Ana Ficticia (EXP-000004): evento 901 está desativado",
      "Ana Ficticia (EXP-000005): evento 901 não aceita mais a letra H"
    ]);
  });

  it("hora sexagesimal com minuto ≥ 60 é recusada pelo layout; centesimal aceita", () => {
    const lancamento = { ...base, valor: "1.75" };
    expect(prepararCsvEventosVariaveis("2026-10-01", [lancamento], false).valido).toBe(false);
    expect(prepararCsvEventosVariaveis("2026-10-01", [lancamento], true).valido).toBe(true);
  });

  it("sem lançamento não há arquivo", () => {
    expect(prepararCsvEventosVariaveis("2026-10-01", [], true)).toMatchObject({
      valido: false,
      pendencias: ["Selecione ao menos um lançamento"]
    });
  });
});

describe("contratos de lançamento e geração", () => {
  const lancamento = {
    competencia: "2026-10-01",
    vinculoId: "00000000-0000-4000-8000-000000000001",
    eventoId: "00000000-0000-4000-8000-000000000002",
    unidade: "V",
    valor: "10.5"
  };

  it("competência é o primeiro dia do mês e valor é positivo com ponto decimal", () => {
    expect(questorEventosVariaveisLancamentoSchema.safeParse(lancamento).success).toBe(true);
    for (const errado of [{ competencia: "2026-10-15" }, { valor: "0" }, { valor: "10,5" }, { valor: "1.23456" }]) {
      expect(
        questorEventosVariaveisLancamentoSchema.safeParse({ ...lancamento, ...errado }).success,
        JSON.stringify(errado)
      ).toBe(false);
    }
  });

  it("geração recusa lançamento repetido e motivo curto demais", () => {
    const id = "00000000-0000-4000-8000-000000000003";
    expect(
      questorEventosVariaveisGeracaoSchema.safeParse({ competencia: "2026-10-01", lancamentoIds: [id, id] }).success
    ).toBe(false);
    expect(
      questorEventosVariaveisGeracaoSchema.safeParse({
        competencia: "2026-10-01",
        lancamentoIds: [id],
        motivoRegeracao: "x"
      }).success
    ).toBe(false);
  });
});
