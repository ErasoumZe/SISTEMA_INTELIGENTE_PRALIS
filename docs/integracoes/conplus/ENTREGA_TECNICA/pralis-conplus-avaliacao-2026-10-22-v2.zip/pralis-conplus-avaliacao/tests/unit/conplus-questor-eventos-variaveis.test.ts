import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { describe, expect, it } from "vitest";
import {
  formatarHorasEventoVariavel,
  lerCsvEventosVariaveis,
  montarCsvEventosVariaveis,
  type ColunaEventoVariavel,
  type ConfiguracaoEmpresaEventosVariaveis
} from "../../shared/src/conplus/index.js";

/**
 * Referência: Questor Docs — "Eventos Variáveis - Importação de Planilha - Dados por Arquivo CSV".
 * O modelo CSV anexado ao e-mail da Conplus NÃO foi localizado; estes testes cobrem a documentação.
 * Os códigos de evento abaixo são FICTÍCIOS: os reais variam por empresa no Questor.
 */
const gerado = (caminho: string) =>
  readFileSync(fileURLToPath(new URL(`../fixtures/conplus-gerados/${caminho}`, import.meta.url)), "utf8");

const SEM_CENTESIMAL: ConfiguracaoEmpresaEventosVariaveis = { utilizaHoraCentesimal: false };
const COM_CENTESIMAL: ConfiguracaoEmpresaEventosVariaveis = { utilizaHoraCentesimal: true };

const colunas: ColunaEventoVariavel[] = [
  { codigoEvento: "9001", unidade: "H", titulo: "HORAS FICTICIAS" },
  { codigoEvento: "9002", unidade: "V", titulo: "VALOR FICTICIO" },
  { codigoEvento: "9003", unidade: "R", titulo: "REFERENCIA FICTICIA" }
];

describe("CSV de eventos variáveis", () => {
  it("monta linhas 1 (códigos), 2 (H/V/R), 3 (título) e dados a partir da coluna 3", () => {
    const { conteudo, valido } = montarCsvEventosVariaveis({
      colunas,
      configuracao: SEM_CENTESIMAL,
      linhas: [
        { codigoEmpregado: "101", nome: "Pessoa Ficticia Um", valores: ["1,50", "120,35", "2"] },
        { codigoEmpregado: "102", nome: null, valores: [null, "80,00", null] }
      ]
    });
    expect(valido).toBe(true);
    expect(conteudo.split("\r\n")).toEqual([
      ";;9001;9002;9003",
      ";;H;V;R",
      "Empregado;Nome;HORAS FICTICIAS;VALOR FICTICIO;REFERENCIA FICTICIA",
      "101;Pessoa Ficticia Um;1,50;120,35;2",
      "102;;;80,00;",
      ""
    ]);
    expect(conteudo).toBe(gerado("eventos_variaveis_ficticio_pralis.csv"));
  });

  it("formata horas conforme 'Utiliza Hora Centesimal' da empresa (exemplo 1,50 da documentação)", () => {
    expect(formatarHorasEventoVariavel(110, false)).toBe("1,50"); // 1h50 sem centesimal
    expect(formatarHorasEventoVariavel(90, true)).toBe("1,50"); // 1h30 com centesimal
    expect(formatarHorasEventoVariavel(90, false)).toBe("1,30");
    expect(() => formatarHorasEventoVariavel(1, true)).toThrow();
  });

  it("recusa minuto 60+ quando a empresa não usa hora centesimal", () => {
    const linhas = [{ codigoEmpregado: "101", valores: ["1,75", null, null] }];
    expect(montarCsvEventosVariaveis({ colunas, linhas, configuracao: SEM_CENTESIMAL }).diagnosticos[0]?.codigo).toBe(
      "HORA"
    );
    expect(montarCsvEventosVariaveis({ colunas, linhas, configuracao: COM_CENTESIMAL }).valido).toBe(true);
  });

  it("não presume código de evento: valida contra o catálogo de CADA empresa", () => {
    const linhas = [{ codigoEmpregado: "101", valores: ["1,00", "10,00", "1"] }];
    const empresaX = new Map([
      ["9001", ["H"] as const],
      ["9002", ["V"] as const],
      ["9003", ["R"] as const]
    ]);
    const empresaY = new Map([["9001", ["V"] as const]]);
    expect(
      montarCsvEventosVariaveis({ colunas, linhas, configuracao: { ...SEM_CENTESIMAL, catalogo: empresaX } }).valido
    ).toBe(true);
    const y = montarCsvEventosVariaveis({ colunas, linhas, configuracao: { ...SEM_CENTESIMAL, catalogo: empresaY } });
    expect(y.diagnosticos.map((item) => `${item.codigo}:${item.coluna}`)).toEqual([
      "UNIDADE:3",
      "CODIGO_EVENTO:4",
      "CODIGO_EVENTO:5"
    ]);
  });

  it("aponta letra fora de H/R/V, empregado sem código, valor com milhar e linha duplicada", () => {
    const { diagnosticos } = montarCsvEventosVariaveis({
      colunas: [{ codigoEvento: "9001", unidade: "X" as never }],
      configuracao: SEM_CENTESIMAL,
      linhas: [
        { codigoEmpregado: "Fulano", valores: ["1.000,00"] },
        { codigoEmpregado: "Fulano", valores: [null] }
      ]
    });
    expect(diagnosticos.map((item) => item.codigo)).toEqual([
      "UNIDADE",
      "EMPREGADO",
      "VALOR",
      "EMPREGADO",
      "DUPLICIDADE"
    ]);
  });

  it("lê o layout da documentação: coluna vazia e linha 3 com texto livre não atrapalham", () => {
    const texto = [
      "#;#;9001;9002;;9003",
      "#;#;H;V;;R",
      "Empregado;Nome;qualquer;coisa;aleatoria;aqui",
      "101;ignorado;1,30;50,00;;3",
      "102;;;;;"
    ].join("\r\n");
    const lido = lerCsvEventosVariaveis(texto, SEM_CENTESIMAL);
    expect(lido.diagnosticos).toEqual([]);
    expect(lido.colunas.map((coluna) => `${coluna.codigoEvento}${coluna.unidade}`)).toEqual([
      "9001H",
      "9002V",
      "9003R"
    ]);
    expect(lido.linhas).toEqual([
      { codigoEmpregado: "101", nome: "ignorado", valores: ["1,30", "50,00", "3"] },
      { codigoEmpregado: "102", nome: "", valores: [null, null, null] }
    ]);
  });

  it("o CSV gerado pelo Pralís relido pelo leitor não perde nada", () => {
    const lido = lerCsvEventosVariaveis(gerado("eventos_variaveis_ficticio_pralis.csv"), SEM_CENTESIMAL);
    expect(lido.diagnosticos).toEqual([]);
    expect(lido.linhas.map((linha) => linha.codigoEmpregado)).toEqual(["101", "102"]);
  });
});
