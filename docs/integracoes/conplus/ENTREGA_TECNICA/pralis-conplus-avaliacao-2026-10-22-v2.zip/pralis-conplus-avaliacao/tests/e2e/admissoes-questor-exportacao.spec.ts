import { expect, test, type Page } from "@playwright/test";
import { entrar, observarConsole, semRolagemHorizontal, USUARIOS } from "./apoio.js";

/**
 * Exportações Questor e Configuração Questor no navegador real: fluxo do DP (prévia do CSV, TXT
 * técnico, histórico com novo download) e as larguras do Definition of Done sem rolagem horizontal.
 *
 * Roda contra um banco ISOLADO com dados fictícios: função, turno, uma admissão aprovada, três
 * vínculos (dois com contrato Questor) e lançamentos da competência 10/2026. Quando o Nuxt de
 * desenvolvimento aponta para outra API, `E2E_API_REDIRECIONAR` desvia as chamadas do navegador para
 * a API isolada — o dev e o banco de dev não recebem nada.
 */
const LARGURAS = [
  { nome: "1440", largura: 1440, altura: 900 },
  { nome: "1024", largura: 1024, altura: 768 },
  { nome: "768", largura: 768, altura: 1024 },
  { nome: "390", largura: 390, altura: 844 }
] as const;
const CAPTURAS = process.env["E2E_CAPTURAS"];

async function desviarApi(page: Page) {
  const destino = process.env["E2E_API_REDIRECIONAR"];
  if (!destino) return;
  await page.route("http://localhost:4100/**", (rota) =>
    rota.continue({ url: rota.request().url().replace("http://localhost:4100", destino) })
  );
}

async function capturar(page: Page, nome: string) {
  if (CAPTURAS) await page.screenshot({ path: `${CAPTURAS}/${nome}.png`, fullPage: true });
}

test.describe("exportações Questor", () => {
  test.setTimeout(300_000);

  test("DP confere o CSV, baixa o TXT técnico e o histórico permite baixar de novo", async ({ page }) => {
    const problemas = observarConsole(page);
    await desviarApi(page);
    await entrar(page, USUARIOS.dp);
    await page.goto("/conplus/exportar");
    await expect(page.getByRole("heading", { name: "Exportações Questor", exact: true })).toBeVisible();

    // CSV: competência 10/2026 já tem três lançamentos selecionados por padrão.
    await page.getByLabel("Competência").fill("2026-10");
    await expect(page.getByRole("cell", { name: "Bruno Ficticio", exact: true })).toBeVisible();
    await page.getByRole("button", { name: "Conferir CSV" }).click();
    const csv = page.locator("pre.eventos__csv");
    await expect(csv).toContainText(";;901;902");
    await expect(csv).toContainText("120;Ana Ficticia;1,30;150,50");
    await expect(page.getByText("CSV oficial bloqueado até a homologação da Conplus.")).toBeVisible();
    await expect(page.getByRole("button", { name: "Gerar CSV oficial" })).toBeDisabled();

    // TXT técnico da admissão aprovada.
    await page.getByLabel("Joana Ficticia Admissao").check();
    const download = page.waitForEvent("download");
    await page.getByRole("button", { name: "Baixar TXT técnico" }).click();
    expect((await download).suggestedFilename()).toMatch(/^TECNICO-NAO-IMPORTAR-admissao-questor-[0-9a-f]{12}\.txt$/u);
    await expect(page.getByText(/registrado no histórico|reaproveitada/u)).toBeVisible();

    // Histórico: o arquivo técnico aparece e baixa de novo com o mesmo nome.
    const item = page.locator(".historico__item").filter({ hasText: "Técnico (não importar)" }).first();
    await expect(item).toBeVisible();
    const deNovo = page.waitForEvent("download");
    await item.getByRole("button", { name: "Baixar" }).click();
    expect((await deNovo).suggestedFilename()).toContain("TECNICO-NAO-IMPORTAR-");

    expect(problemas, problemas.join("\n")).toEqual([]);
  });

  test("Exportações e Configuração Questor sem rolagem horizontal em 1440/1024/768/390", async ({ page }) => {
    const problemas = observarConsole(page);
    await desviarApi(page);
    await entrar(page, USUARIOS.dp);
    for (const { nome, largura, altura } of LARGURAS) {
      await page.setViewportSize({ width: largura, height: altura });
      await page.goto("/conplus/exportar");
      await expect(page.getByRole("heading", { name: "Exportações Questor", exact: true }), nome).toBeVisible();
      await page.getByLabel("Competência").fill("2026-10");
      await expect(page.getByRole("cell", { name: "Ana Ficticia", exact: true }).first()).toBeVisible();
      await page.getByRole("button", { name: "Conferir CSV" }).click();
      await expect(page.locator("pre.eventos__csv")).toBeVisible();
      await semRolagemHorizontal(page);
      await capturar(page, `exportar-${nome}`);

      await page.goto("/questor");
      await expect(page.getByRole("heading", { name: "Contratos no Questor" }), nome).toBeVisible();
      await expect(page.getByText("1 sem código")).toBeVisible();
      await semRolagemHorizontal(page);
      await capturar(page, `questor-${nome}`);
    }
    expect(problemas, problemas.join("\n")).toEqual([]);
  });
});
