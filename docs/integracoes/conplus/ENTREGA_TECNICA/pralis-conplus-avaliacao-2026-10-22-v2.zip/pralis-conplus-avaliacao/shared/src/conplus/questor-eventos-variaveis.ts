import { parseCsvPontoEVirgula } from "./parsers.js";

/**
 * Eventos Variáveis — importação de planilha por arquivo CSV (Questor 23.3.0.0+, menu
 * Cálculo / Eventos Variáveis / Importação Planilha).
 *
 * Estrutura da documentação oficial, linha a linha:
 * - Linha 1: códigos dos eventos, a partir da coluna 3.
 * - Linha 2: letra do campo de cada evento, a partir da coluna 3 — H (horas), V (valor), R (referência).
 * - Linha 3: não é importada; título livre (recomendado).
 * - Linha 4 em diante: coluna 1 = código do empregado (obrigatório); coluna 2 não é avaliada;
 *   da coluna 3 em diante, horas/valores/referências.
 * - Colunas 1 e 2 das linhas 1 a 3 recebem "#" do próprio Questor na importação: o conteúdo é ignorado.
 * - Separador `;`. Colunas totalmente vazias são aceitas.
 * - Horas dependem de "Utiliza Hora Centesimal" NA EMPRESA: "1,50" é 1h50 sem centesimal e 1h30 com.
 * - Importar duas vezes a mesma planilha DUPLICA os lançamentos; erro em qualquer linha aborta tudo.
 *
 * Códigos de evento são da EMPRESA no Questor. Por isso o catálogo entra como parâmetro: este módulo
 * não conhece código de evento nenhum, e não deve conhecer.
 */

export type UnidadeEventoVariavel = "H" | "R" | "V";
export const UNIDADES_EVENTO_VARIAVEL: readonly UnidadeEventoVariavel[] = ["H", "R", "V"];

export type ColunaEventoVariavel = {
  codigoEvento: string;
  unidade: UnidadeEventoVariavel;
  /** Vai para a linha 3, que o Questor não importa. */
  titulo?: string | null;
};

export type LinhaEventoVariavel = {
  codigoEmpregado: string;
  /** Coluna 2: não avaliada pelo Questor. */
  nome?: string | null;
  /** Um valor por coluna de evento, na mesma ordem. Vazio = sem lançamento daquele evento. */
  valores: readonly (string | null)[];
};

export type ConfiguracaoEmpresaEventosVariaveis = {
  /** Configurações/Empresa → "Utiliza Hora Centesimal" no Questor da empresa de destino. */
  utilizaHoraCentesimal: boolean;
  /** Eventos que a empresa tem no Questor e as letras aceitas por eles. Sem catálogo, não há validação de código. */
  catalogo?: ReadonlyMap<string, readonly UnidadeEventoVariavel[]>;
};

export type DiagnosticoEventoVariavel = {
  linha: number;
  coluna: number | null;
  codigo:
    | "ESTRUTURA"
    | "CODIGO_EVENTO"
    | "UNIDADE"
    | "EMPREGADO"
    | "VALOR"
    | "HORA"
    | "CARACTERE_PROIBIDO"
    | "DUPLICIDADE";
  mensagem: string;
};

const FIM_DE_LINHA = "\r\n";
const NUMERO_DECIMAL = /^\d+(,\d+)?$/u;

/**
 * Converte minutos para o texto que o Questor interpreta conforme a configuração da empresa.
 * Centesimal: 90 min → "1,50". Sexagesimal: 90 min → "1,30".
 */
export function formatarHorasEventoVariavel(minutos: number, utilizaHoraCentesimal: boolean): string {
  if (!Number.isInteger(minutos) || minutos < 0) throw new Error("Minutos devem ser inteiro não negativo");
  const horas = Math.floor(minutos / 60);
  const resto = minutos % 60;
  if (!utilizaHoraCentesimal) return `${horas},${String(resto).padStart(2, "0")}`;
  const centesimos = (resto * 100) / 60;
  if (!Number.isInteger(centesimos)) {
    throw new Error(`${minutos} minutos não têm representação exata em hora centesimal com duas casas`);
  }
  return `${horas},${String(centesimos).padStart(2, "0")}`;
}

function validarValor(
  valor: string,
  unidade: UnidadeEventoVariavel,
  configuracao: ConfiguracaoEmpresaEventosVariaveis,
  linha: number,
  coluna: number,
  diagnosticos: DiagnosticoEventoVariavel[]
): void {
  if (!NUMERO_DECIMAL.test(valor)) {
    diagnosticos.push({
      linha,
      coluna,
      codigo: "VALOR",
      mensagem: `Valor "${valor}" deve ser número com vírgula decimal, sem milhar`
    });
    return;
  }
  if (unidade === "H" && !configuracao.utilizaHoraCentesimal) {
    const minutos = valor.split(",")[1] ?? "0";
    if (minutos.length > 2 || Number(minutos.padEnd(2, "0")) >= 60) {
      diagnosticos.push({
        linha,
        coluna,
        codigo: "HORA",
        mensagem: `Hora "${valor}" inválida para empresa sem hora centesimal: minutos vão de 00 a 59`
      });
    }
  }
}

function validarCabecalho(
  colunas: readonly ColunaEventoVariavel[],
  configuracao: ConfiguracaoEmpresaEventosVariaveis,
  diagnosticos: DiagnosticoEventoVariavel[]
): void {
  if (colunas.length === 0)
    diagnosticos.push({ linha: 1, coluna: 3, codigo: "ESTRUTURA", mensagem: "Nenhum evento informado" });
  colunas.forEach((coluna, indice) => {
    const posicao = indice + 3;
    if (!/^\d+$/u.test(coluna.codigoEvento)) {
      diagnosticos.push({
        linha: 1,
        coluna: posicao,
        codigo: "CODIGO_EVENTO",
        mensagem: `Código de evento inválido: "${coluna.codigoEvento}"`
      });
    }
    if (!UNIDADES_EVENTO_VARIAVEL.includes(coluna.unidade)) {
      diagnosticos.push({
        linha: 2,
        coluna: posicao,
        codigo: "UNIDADE",
        mensagem: `Letra "${coluna.unidade}" não é H, R ou V`
      });
    }
    const aceitas = configuracao.catalogo?.get(coluna.codigoEvento);
    if (configuracao.catalogo && !aceitas) {
      diagnosticos.push({
        linha: 1,
        coluna: posicao,
        codigo: "CODIGO_EVENTO",
        mensagem: `Evento ${coluna.codigoEvento} não existe no catálogo da empresa`
      });
    } else if (aceitas && !aceitas.includes(coluna.unidade)) {
      diagnosticos.push({
        linha: 2,
        coluna: posicao,
        codigo: "UNIDADE",
        mensagem: `Evento ${coluna.codigoEvento} não aceita a letra ${coluna.unidade} nesta empresa`
      });
    }
    if (/[;\r\n]/u.test(coluna.titulo ?? "")) {
      diagnosticos.push({
        linha: 3,
        coluna: posicao,
        codigo: "CARACTERE_PROIBIDO",
        mensagem: "Título com ';' ou quebra de linha"
      });
    }
  });
}

export function montarCsvEventosVariaveis(input: {
  colunas: readonly ColunaEventoVariavel[];
  linhas: readonly LinhaEventoVariavel[];
  configuracao: ConfiguracaoEmpresaEventosVariaveis;
}): { conteudo: string; diagnosticos: DiagnosticoEventoVariavel[]; valido: boolean } {
  const { colunas, linhas, configuracao } = input;
  const diagnosticos: DiagnosticoEventoVariavel[] = [];
  validarCabecalho(colunas, configuracao, diagnosticos);

  const vistos = new Set<string>();
  const corpo = linhas.map((linha, indice) => {
    const numero = indice + 4;
    if (!/^\d+$/u.test(linha.codigoEmpregado)) {
      diagnosticos.push({
        linha: numero,
        coluna: 1,
        codigo: "EMPREGADO",
        mensagem: "Coluna 1 deve conter o código do empregado no Questor"
      });
    }
    if (vistos.has(linha.codigoEmpregado)) {
      // Guarda do Pralís, não regra do Questor: duas linhas do mesmo empregado viram dois lançamentos.
      diagnosticos.push({
        linha: numero,
        coluna: 1,
        codigo: "DUPLICIDADE",
        mensagem: `Empregado ${linha.codigoEmpregado} repetido no arquivo`
      });
    }
    vistos.add(linha.codigoEmpregado);
    if (/[;\r\n]/u.test(linha.nome ?? "")) {
      diagnosticos.push({
        linha: numero,
        coluna: 2,
        codigo: "CARACTERE_PROIBIDO",
        mensagem: "Nome com ';' ou quebra de linha"
      });
    }
    if (linha.valores.length !== colunas.length) {
      diagnosticos.push({
        linha: numero,
        coluna: null,
        codigo: "ESTRUTURA",
        mensagem: `Esperado ${colunas.length} valores, recebido ${linha.valores.length}`
      });
    }
    linha.valores.forEach((valor, posicao) => {
      const unidade = colunas[posicao]?.unidade;
      if (valor && unidade) validarValor(valor, unidade, configuracao, numero, posicao + 3, diagnosticos);
    });
    return [linha.codigoEmpregado, linha.nome ?? "", ...linha.valores.map((valor) => valor ?? "")].join(";");
  });

  const cabecalho = [
    ["", "", ...colunas.map((coluna) => coluna.codigoEvento)].join(";"),
    ["", "", ...colunas.map((coluna) => coluna.unidade)].join(";"),
    ["Empregado", "Nome", ...colunas.map((coluna) => coluna.titulo ?? "")].join(";")
  ];
  const conteudo = [...cabecalho, ...corpo].map((linha) => linha + FIM_DE_LINHA).join("");
  return { conteudo, diagnosticos, valido: diagnosticos.length === 0 };
}

/** Lê um CSV de eventos variáveis (inclusive um modelo recebido) e confere contra a documentação. */
export function lerCsvEventosVariaveis(
  texto: string,
  configuracao: ConfiguracaoEmpresaEventosVariaveis
): { colunas: ColunaEventoVariavel[]; linhas: LinhaEventoVariavel[]; diagnosticos: DiagnosticoEventoVariavel[] } {
  const diagnosticos: DiagnosticoEventoVariavel[] = [];
  const bruto = (texto.charCodeAt(0) === 0xfeff ? texto.slice(1) : texto).replace(/\r\n?/gu, "\n").split("\n");
  while (bruto.length && bruto[bruto.length - 1] === "") bruto.pop();
  if (bruto.length < 3) {
    diagnosticos.push({
      linha: 1,
      coluna: null,
      codigo: "ESTRUTURA",
      mensagem: "Arquivo precisa das linhas 1 (códigos), 2 (H/V/R) e 3 (título)"
    });
    return { colunas: [], linhas: [], diagnosticos };
  }
  const tabela = bruto.map((linha) => parseCsvPontoEVirgula(linha)[0] ?? [""]);
  const [codigos = [], unidades = [], titulos = []] = tabela;
  const colunas: ColunaEventoVariavel[] = [];
  const indices: number[] = [];
  for (let indice = 2; indice < Math.max(codigos.length, unidades.length); indice += 1) {
    const codigo = (codigos[indice] ?? "").trim();
    const unidade = (unidades[indice] ?? "").trim().toUpperCase();
    if (!codigo && !unidade) continue; // coluna vazia é aceita pela documentação
    colunas.push({ codigoEvento: codigo, unidade: unidade as UnidadeEventoVariavel, titulo: titulos[indice] ?? null });
    indices.push(indice);
  }
  validarCabecalho(colunas, configuracao, diagnosticos);
  diagnosticos.forEach((diagnostico) => {
    if (diagnostico.coluna !== null)
      diagnostico.coluna = (indices[diagnostico.coluna - 3] ?? diagnostico.coluna - 1) + 1;
  });
  const linhas: LinhaEventoVariavel[] = tabela.slice(3).map((partes, posicao) => {
    const numero = posicao + 4;
    const codigoEmpregado = (partes[0] ?? "").trim();
    if (!/^\d+$/u.test(codigoEmpregado)) {
      diagnosticos.push({
        linha: numero,
        coluna: 1,
        codigo: "EMPREGADO",
        mensagem: "Coluna 1 deve conter o código do empregado no Questor"
      });
    }
    const valores = indices.map((indice, ordem) => {
      const valor = (partes[indice] ?? "").trim();
      const unidade = colunas[ordem]?.unidade;
      if (valor && unidade) validarValor(valor, unidade, configuracao, numero, indice + 1, diagnosticos);
      return valor || null;
    });
    return { codigoEmpregado, nome: partes[1] ?? null, valores };
  });
  return { colunas, linhas, diagnosticos };
}

// --- Lançamentos do Pralís → CSV ------------------------------------------------------------------

export type LancamentoParaCsvQuestor = {
  id: string;
  competencia: string;
  colaboradorNome: string;
  matricula: string;
  questorCodigoContrato: string | null;
  eventoCodigo: string;
  eventoDescricao: string;
  eventoAtivo: boolean;
  eventoUnidades: readonly string[];
  unidade: UnidadeEventoVariavel;
  /** Como o PostgreSQL devolve `numeric(18,4)`: ponto decimal ("1.5000"). */
  valor: string;
};

/**
 * Valor do banco → texto do CSV: vírgula decimal, sem milhar, ao menos 2 casas e sem zeros
 * desnecessários além delas ("1.5000" → "1,50"; "12.3456" → "12,3456"). O número não é convertido:
 * para H ele já foi digitado na convenção de horas da empresa.
 */
export function formatarValorEventoVariavel(valor: string): string {
  const [inteiro = "0", fracao = ""] = valor.trim().split(".");
  const casas = fracao.replace(/0+$/u, "").padEnd(2, "0");
  return `${inteiro.replace(/^0+(?=\d)/u, "")},${casas}`;
}

const semSeparador = (texto: string) =>
  texto
    .replace(/[;\r\n]+/gu, " ")
    .replace(/\s{2,}/gu, " ")
    .trim();

/**
 * Agrupa lançamentos em colunas (evento + letra) e linhas (um contrato por linha). Tudo que impede o
 * arquivo e depende do Pralís vira `pendencias` com o nome de quem resolve; o validador do layout
 * roda depois, em `montarCsvEventosVariaveis`.
 */
export function prepararCsvEventosVariaveis(
  competencia: string,
  lancamentos: readonly LancamentoParaCsvQuestor[],
  utilizaHoraCentesimal: boolean | null
): {
  conteudo: string;
  valido: boolean;
  pendencias: string[];
  diagnosticos: DiagnosticoEventoVariavel[];
  quantidadeEmpregados: number;
} {
  const pendencias: string[] = [];
  if (utilizaHoraCentesimal === null) {
    pendencias.push('Configure "Utiliza Hora Centesimal" da empresa em Configuração Questor');
  }
  for (const lancamento of lancamentos) {
    const quem = `${lancamento.colaboradorNome} (${lancamento.matricula})`;
    if (lancamento.competencia !== competencia) {
      pendencias.push(`${quem}: lançamento de outra competência (${lancamento.competencia})`);
    }
    if (!lancamento.questorCodigoContrato) {
      pendencias.push(`${quem}: sem código de contrato Questor (Configuração Questor → Contratos no Questor)`);
    }
    if (!lancamento.eventoAtivo) pendencias.push(`${quem}: evento ${lancamento.eventoCodigo} está desativado`);
    if (!lancamento.eventoUnidades.includes(lancamento.unidade)) {
      pendencias.push(`${quem}: evento ${lancamento.eventoCodigo} não aceita mais a letra ${lancamento.unidade}`);
    }
  }
  const unicas = [...new Set(pendencias)];

  const chaveColuna = (lancamento: LancamentoParaCsvQuestor) => `${lancamento.eventoCodigo}|${lancamento.unidade}`;
  const colunasPorChave = new Map<string, ColunaEventoVariavel>();
  for (const lancamento of lancamentos) {
    colunasPorChave.set(chaveColuna(lancamento), {
      codigoEvento: lancamento.eventoCodigo,
      unidade: lancamento.unidade,
      titulo: semSeparador(lancamento.eventoDescricao)
    });
  }
  const chaves = [...colunasPorChave.keys()].sort((a, b) => {
    const [codigoA = "", unidadeA = ""] = a.split("|");
    const [codigoB = "", unidadeB = ""] = b.split("|");
    return Number(codigoA) - Number(codigoB) || unidadeA.localeCompare(unidadeB);
  });
  const colunas = chaves.map((chave) => colunasPorChave.get(chave)!);

  const porEmpregado = new Map<string, { nome: string; valores: (string | null)[] }>();
  for (const lancamento of lancamentos) {
    const codigo = lancamento.questorCodigoContrato ?? "";
    const linha = porEmpregado.get(codigo) ?? {
      nome: semSeparador(lancamento.colaboradorNome),
      valores: chaves.map(() => null)
    };
    linha.valores[chaves.indexOf(chaveColuna(lancamento))] = formatarValorEventoVariavel(lancamento.valor);
    porEmpregado.set(codigo, linha);
  }
  const linhas: LinhaEventoVariavel[] = [...porEmpregado.entries()]
    .sort(([a], [b]) => Number(a) - Number(b))
    .map(([codigoEmpregado, linha]) => ({ codigoEmpregado, nome: linha.nome, valores: linha.valores }));

  const catalogo = new Map<string, readonly UnidadeEventoVariavel[]>();
  for (const lancamento of lancamentos) {
    catalogo.set(
      lancamento.eventoCodigo,
      lancamento.eventoUnidades.filter((unidade): unidade is UnidadeEventoVariavel =>
        UNIDADES_EVENTO_VARIAVEL.includes(unidade as UnidadeEventoVariavel)
      )
    );
  }
  const csv = montarCsvEventosVariaveis({
    colunas,
    linhas,
    configuracao: { utilizaHoraCentesimal: utilizaHoraCentesimal ?? false, catalogo }
  });
  const valido = csv.valido && unicas.length === 0 && lancamentos.length > 0;
  return {
    conteudo: valido ? csv.conteudo : "",
    valido,
    pendencias: lancamentos.length ? unicas : ["Selecione ao menos um lançamento"],
    diagnosticos: csv.diagnosticos,
    quantidadeEmpregados: linhas.length
  };
}
