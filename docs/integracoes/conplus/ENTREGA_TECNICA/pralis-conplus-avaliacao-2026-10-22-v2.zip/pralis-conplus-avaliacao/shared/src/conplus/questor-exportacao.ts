import { z } from "zod";

/**
 * Contratos das exportações Questor (TXT de admissão e CSV de eventos variáveis).
 *
 * Três níveis, do mais livre ao mais protegido:
 * - **prévia**: valida e mostra; não grava nada;
 * - **arquivo técnico** (só admissão): gera o TXT mesmo com pendências oficiais, com nome
 *   `TECNICO-NAO-IMPORTAR-…`, e registra na auditoria como `previa`. Serve para conferência interna
 *   e para enviar à Conplus como amostra — nunca para importar;
 * - **arquivo oficial**: só com os dois gates de homologação ligados (`CONPLUS_QUESTOR_EXPORT_ENABLED`
 *   e `CONPLUS_QUESTOR_EXPORT_HOMOLOGADA`) e o arquivo sem nenhuma pendência; registrado como `gerado`.
 *
 * Todo arquivo gravado fica no storage, identificado pelo SHA-256 do conteúdo, e pode ser baixado de
 * novo pelo histórico. O mesmo conteúdo gerado duas vezes devolve o registro existente.
 */

export const ROTAS_EXPORTACAO_QUESTOR = {
  admissoesPrevia: "/api/conplus/questor/exportacoes/admissoes/previa",
  admissoesTecnico: "/api/conplus/questor/exportacoes/admissoes/tecnico",
  admissoesDownload: "/api/conplus/questor/exportacoes/admissoes/download",
  eventosPrevia: "/api/conplus/questor/exportacoes/eventos/previa",
  eventosDownload: "/api/conplus/questor/exportacoes/eventos/download",
  historico: "/api/conplus/questor/exportacoes",
  arquivo: "/api/conplus/questor/exportacoes/:id/arquivo",
  eventos: "/api/conplus/questor/eventos",
  evento: "/api/conplus/questor/eventos/:id",
  lancamentos: "/api/conplus/questor/eventos/lancamentos",
  lancamento: "/api/conplus/questor/eventos/lancamentos/:id"
} as const;

export const ERROS_EXPORTACAO_QUESTOR = {
  naoHomologada: "QUESTOR_EXPORTACAO_NAO_HOMOLOGADA",
  invalida: "QUESTOR_EXPORTACAO_INVALIDA",
  jaExportado: "QUESTOR_EXPORTACAO_JA_REALIZADA",
  arquivoAusente: "QUESTOR_EXPORTACAO_ARQUIVO_AUSENTE",
  processoNaoExportavel: "QUESTOR_PROCESSO_NAO_EXPORTAVEL",
  lancamentoExportado: "QUESTOR_LANCAMENTO_JA_EXPORTADO"
} as const;

export const VERSAO_LAYOUT_ADMISSAO_QUESTOR = "questor-admissao-v2";
export const VERSAO_LAYOUT_EVENTOS_QUESTOR = "questor-eventos-variaveis-23.3";

const idsUnicos = <T extends z.ZodTypeAny>(item: T, maximo: number) =>
  z
    .array(item)
    .min(1)
    .max(maximo)
    .refine((lista) => new Set(lista).size === lista.length, "Itens repetidos na seleção");

/** Reexportar algo já exportado exige justificativa: o Questor duplicaria o lançamento/contrato. */
const motivoRegeracao = z.string().trim().min(5).max(500).optional();
const competencia = z.string().regex(/^\d{4}-\d{2}-01$/u, "Competência é o primeiro dia do mês (AAAA-MM-01)");

export const questorExportacaoPreviaRequisicaoSchema = z
  .object({ processoIds: idsUnicos(z.string().uuid(), 50) })
  .strict();

export const questorExportacaoAdmissaoRequisicaoSchema = z
  .object({ processoIds: idsUnicos(z.string().uuid(), 50), motivoRegeracao })
  .strict();

export type QuestorExportacaoPreviaRequisicao = z.infer<typeof questorExportacaoPreviaRequisicaoSchema>;

export type QuestorExportacaoPreviaRegistro = {
  processoId: string;
  situacao: "pronto" | "bloqueado";
  fichaAprovada: boolean;
  quantidadeLinhas: number;
  pendencias: readonly string[];
  diagnosticos: readonly string[];
};

export type QuestorExportacaoPreviaDto = {
  tipo: "admissao";
  /** `true` só com os dois gates de homologação ligados no servidor. */
  exportacaoDisponivel: boolean;
  homologacaoConplusConfirmada: boolean;
  bloqueio: "QUESTOR_EXPORTACAO_NAO_HOMOLOGADA" | null;
  registros: readonly QuestorExportacaoPreviaRegistro[];
};

// --- Eventos variáveis -------------------------------------------------------------------------------

export const questorEventosVariaveisCatalogoSchema = z
  .object({
    codigo: z.string().regex(/^\d+$/u).max(20),
    descricao: z
      .string()
      .trim()
      .min(1)
      .max(200)
      .refine((valor) => !/[;\r\n]/u.test(valor), "Descrição sem ';' nem quebra de linha"),
    unidades: z
      .array(z.enum(["H", "R", "V"]))
      .min(1)
      .max(3)
      .refine((lista) => new Set(lista).size === lista.length, "Unidade repetida")
  })
  .strict();

/** Código e unidades não mudam (seriam outro evento): corrige-se desativando e cadastrando outro. */
export const questorEventoVariavelAtualizacaoSchema = z
  .object({
    descricao: z
      .string()
      .trim()
      .min(1)
      .max(200)
      .refine((valor) => !/[;\r\n]/u.test(valor), "Descrição sem ';' nem quebra de linha")
      .optional(),
    ativo: z.boolean().optional()
  })
  .strict()
  .refine((dados) => dados.descricao !== undefined || dados.ativo !== undefined, "Informe descrição ou situação");

/**
 * `valor` com ponto decimal, sem milhar. Para a letra H, o valor é digitado na convenção de horas
 * da empresa no Questor (com hora centesimal, 1.50 = 1h30; sem, 1.30 = 1h30) — o arquivo leva o
 * número como digitado, com vírgula.
 */
export const questorEventosVariaveisLancamentoSchema = z
  .object({
    competencia,
    vinculoId: z.string().uuid(),
    eventoId: z.string().uuid(),
    unidade: z.enum(["H", "R", "V"]),
    valor: z
      .string()
      .regex(/^\d{1,14}(\.\d{1,4})?$/u, "Valor com ponto decimal, até 4 casas")
      .refine((valor) => Number(valor) > 0, "Valor precisa ser maior que zero")
  })
  .strict();

export type QuestorEventosVariaveisCatalogo = z.infer<typeof questorEventosVariaveisCatalogoSchema>;
export type QuestorEventosVariaveisLancamento = z.infer<typeof questorEventosVariaveisLancamentoSchema>;

export const questorEventosVariaveisPreviaSchema = z
  .object({ competencia, lancamentoIds: idsUnicos(z.string().uuid(), 10_000) })
  .strict();

export const questorEventosVariaveisGeracaoSchema = z
  .object({ competencia, lancamentoIds: idsUnicos(z.string().uuid(), 10_000), motivoRegeracao })
  .strict();

export const questorEventosVariaveisQuerySchema = z.object({ competencia: competencia.optional() }).strict();

export type QuestorEventosVariaveisPreviaDto = {
  tipo: "eventos_variaveis";
  competencia: string;
  exportacaoDisponivel: boolean;
  homologacaoConplusConfirmada: boolean;
  bloqueio: "QUESTOR_EXPORTACAO_NAO_HOMOLOGADA" | null;
  quantidadeRegistros: number;
  quantidadeEmpregados: number;
  /** `true` = o CSV cumpre o layout e o catálogo da empresa. */
  valido: boolean;
  /** Dados do Pralís que faltam (ex.: colaborador sem código de contrato Questor). */
  pendencias: readonly string[];
  /** Erros do layout apontados pelo validador do CSV. */
  diagnosticos: readonly string[];
  /** Lançamentos da seleção que já saíram em arquivo oficial (gerar de novo exige motivo). */
  jaExportados: number;
  /** Conteúdo do CSV como seria gerado (vazio enquanto houver pendência). */
  conteudo: string;
};

export type QuestorLancamentoVariavelDto = {
  id: string;
  competencia: string;
  vinculoId: string;
  colaboradorNome: string;
  matricula: string;
  questorCodigoContrato: string | null;
  eventoId: string;
  eventoCodigo: string;
  eventoDescricao: string;
  unidade: "H" | "R" | "V";
  valor: string;
  exportado: boolean;
};

// --- Histórico e download ----------------------------------------------------------------------------

export const questorExportacoesQuerySchema = z
  .object({
    tipo: z.enum(["admissao", "eventos_variaveis"]).optional(),
    limite: z.coerce.number().int().min(1).max(100).default(50)
  })
  .strict();

export type QuestorExportacaoHistoricoDto = {
  id: string;
  tipo: "admissao" | "eventos_variaveis";
  competencia: string | null;
  layoutVersao: string;
  sha256: string;
  resultado: "previa" | "gerado" | "bloqueado" | "falhou";
  nomeArquivo: string | null;
  /** Há arquivo gravado para baixar de novo (bloqueados não têm). */
  temArquivo: boolean;
  diagnosticos: readonly string[];
  motivoRegeracao: string | null;
  geradoPorNome: string | null;
  geradoEm: string;
};

export type QuestorEventoVariavelDto = {
  id: string;
  codigo: string;
  descricao: string;
  unidades: string[];
  ativo: boolean;
};
