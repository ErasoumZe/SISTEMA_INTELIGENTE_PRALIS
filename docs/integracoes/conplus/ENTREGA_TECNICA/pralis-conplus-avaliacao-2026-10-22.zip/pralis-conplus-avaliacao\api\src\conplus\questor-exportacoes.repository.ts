import { and, desc, eq } from "drizzle-orm";
import { questorExportacoes } from "@padaria/db/schema";
import { banco } from "../banco/conexao.js";

export function listarQuestorExportacoesRepository(
  empresaId: string,
  tipo?: "admissao" | "eventos_variaveis",
  limite = 50
) {
  const condicoes = [eq(questorExportacoes.empresaId, empresaId)];
  if (tipo) condicoes.push(eq(questorExportacoes.tipo, tipo));
  return banco
    .select()
    .from(questorExportacoes)
    .where(and(...condicoes))
    .orderBy(desc(questorExportacoes.criadoEm))
    .limit(limite);
}
