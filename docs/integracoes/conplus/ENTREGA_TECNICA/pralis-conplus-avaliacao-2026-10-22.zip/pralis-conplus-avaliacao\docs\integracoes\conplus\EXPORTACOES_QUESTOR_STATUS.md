# Exportações Questor — estado técnico

## Implementado e testado

- Os geradores puros de TXT de admissão (registros A/B/C/D) e CSV de eventos variáveis permanecem
  no pacote compartilhado e são validados sem chamadas à Conplus, Google ou banco.
- A rota autenticada `POST /api/conplus/questor/exportacoes/admissoes/previa` monta a prévia a partir
  do PostgreSQL, sempre limitada à empresa da sessão.
- A prévia exige ficha aprovada, valida o layout oficial, os de-para e os vínculos dos dependentes.
- A tela `/conplus/exportar` e o item **Exportações Questor** no Departamento Pessoal exibem os
  bloqueios por processo.

## Implementado localmente, pendente de migration

Foi preparada a proposta `db/proposals/0067_questor_exportacoes.sql`, não aplicada. Ela cria a
auditoria de exportações, vínculo de processos, catálogo de eventos variáveis, lançamentos e vínculo
dos lançamentos exportados. As FKs compostas sempre carregam `empresa_id`; a chave de idempotência é
`empresa_id + tipo + chave_idempotencia`.

O endpoint autenticado `POST /api/conplus/questor/exportacoes/admissoes/download` já executa o caminho
de geração e auditoria quando as tabelas existirem e os dois gates de configuração estiverem ativos.
Por padrão ele responde `QUESTOR_EXPORTACAO_NAO_HOMOLOGADA`, sem criar arquivo. A geração falha fechada
se a ficha não estiver aprovada, se o layout tiver pendências ou se a migration ainda não existir.

Eventos variáveis também não foram liberados: o catálogo e os lançamentos possuem persistência e
prévia autenticadas, mas ainda faltam o catálogo homologado de eventos por empresa e o modelo CSV
oficial da Conplus. A escrita operacional continua bloqueada e não inventa códigos ou valores.

## Bloqueio da migration

O journal local já registra `0067_e5_campos_candidato` como a migration 0067 oficial. A SQL foi
incorporada localmente como `db/migrations/0068_questor_exportacoes.sql`, preservando a 0067, mas
o journal e o snapshot ainda não foram atualizados.
Além disso, a geração automática do snapshot pela ferramenta do Drizzle está bloqueada neste
ambiente por `uv_os_get_passwd returned ENOMEM`. A proposta foi validada em PostgreSQL descartável,
mas permanece pendente até gerar snapshot/journal oficiais.

## Próxima etapa autorizável

Após definir um número posterior livre, revisar a proposta, gerar o snapshot Drizzle oficial e autorizar
a aplicação somente em banco autorizado. Depois disso a Conplus ainda precisa confirmar
o layout/códigos antes de habilitar `CONPLUS_QUESTOR_EXPORT_ENABLED` e
`CONPLUS_QUESTOR_EXPORT_HOMOLOGADA`.
