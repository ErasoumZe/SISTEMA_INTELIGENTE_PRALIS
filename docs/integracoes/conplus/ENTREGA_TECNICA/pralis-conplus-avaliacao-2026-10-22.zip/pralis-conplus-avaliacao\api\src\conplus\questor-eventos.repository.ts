import { and, asc, eq, inArray } from "drizzle-orm";
import { colaboradoresVinculos, questorEventosVariaveis, questorEventosVariaveisLancamentos } from "@padaria/db/schema";
import { banco } from "../banco/conexao.js";

export function listarEventosVariaveisRepository(empresaId: string) {
  return banco
    .select()
    .from(questorEventosVariaveis)
    .where(eq(questorEventosVariaveis.empresaId, empresaId))
    .orderBy(asc(questorEventosVariaveis.codigo));
}

export function inserirEventoVariavelRepository(
  empresaId: string,
  dados: { codigo: string; descricao: string; unidades: string[]; criadoPor: string }
) {
  return banco
    .insert(questorEventosVariaveis)
    .values({ empresaId, ...dados })
    .onConflictDoNothing()
    .returning();
}

export async function inserirLancamentoVariavelRepository(
  empresaId: string,
  dados: {
    competencia: string;
    vinculoId: string;
    eventoId: string;
    unidade: "H" | "R" | "V";
    valor: string;
    criadoPor: string;
  }
) {
  const [vinculo] = await banco
    .select({ id: colaboradoresVinculos.id })
    .from(colaboradoresVinculos)
    .where(and(eq(colaboradoresVinculos.id, dados.vinculoId), eq(colaboradoresVinculos.empresaId, empresaId)))
    .limit(1);
  if (!vinculo) return { kind: "vinculo_inexistente" as const };

  const [evento] = await banco
    .select({ id: questorEventosVariaveis.id, unidades: questorEventosVariaveis.unidades })
    .from(questorEventosVariaveis)
    .where(and(eq(questorEventosVariaveis.id, dados.eventoId), eq(questorEventosVariaveis.empresaId, empresaId)))
    .limit(1);
  if (!evento) return { kind: "evento_inexistente" as const };
  if (!evento.unidades.includes(dados.unidade)) return { kind: "unidade_nao_catalogada" as const };

  const [linha] = await banco
    .insert(questorEventosVariaveisLancamentos)
    .values({ empresaId, ...dados })
    .onConflictDoNothing()
    .returning();
  return linha ? { kind: "criado" as const, linha } : { kind: "duplicado" as const };
}

export function buscarLancamentosVariaveisRepository(empresaId: string, ids: readonly string[]) {
  return banco
    .select()
    .from(questorEventosVariaveisLancamentos)
    .where(
      and(
        eq(questorEventosVariaveisLancamentos.empresaId, empresaId),
        inArray(questorEventosVariaveisLancamentos.id, [...ids])
      )
    );
}

export function listarLancamentosVariaveisRepository(empresaId: string, competencia?: string) {
  const condicoes = [eq(questorEventosVariaveisLancamentos.empresaId, empresaId)];
  if (competencia) condicoes.push(eq(questorEventosVariaveisLancamentos.competencia, competencia));
  return banco
    .select({
      id: questorEventosVariaveisLancamentos.id,
      competencia: questorEventosVariaveisLancamentos.competencia,
      vinculoId: questorEventosVariaveisLancamentos.vinculoId,
      eventoId: questorEventosVariaveisLancamentos.eventoId,
      unidade: questorEventosVariaveisLancamentos.unidade,
      valor: questorEventosVariaveisLancamentos.valor
    })
    .from(questorEventosVariaveisLancamentos)
    .where(and(...condicoes))
    .orderBy(asc(questorEventosVariaveisLancamentos.competencia), asc(questorEventosVariaveisLancamentos.id));
}
