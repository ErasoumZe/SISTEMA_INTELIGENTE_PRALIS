import {
  prepararArquivoAdmissaoQuestor,
  questorExportacaoPreviaRequisicaoSchema,
  questorExportacoesQuerySchema,
  type QuestorExportacaoPreviaDto,
  type SnapshotAdmissaoPralis
} from "@padaria/shared/conplus";
import type { PerfilUsuario } from "@padaria/shared";
import type { DadosExternos } from "@padaria/shared/api";
import { createHash } from "node:crypto";
import { questorExportacoes, questorExportacoesAdmissoes } from "@padaria/db/schema";
import { banco } from "../banco/conexao.js";
import { env } from "../env.js";
import { naoProcessavel } from "../erros.js";
import { atorDoPerfil } from "../admissoes/ator.js";
import { empresaDoAtor } from "../admissoes/ator.js";
import { obterProcessoRepository } from "../admissoes/processos.repository.js";
import { lerParametrosQuestorRepository } from "./questor-parametros.repository.js";
import { lerSnapshotQuestorRepository } from "./questor-prontidao.repository.js";
import { comMigrationQuestor } from "./questor-comum.service.js";
import { listarQuestorExportacoesRepository } from "./questor-exportacoes.repository.js";

/** Prévia server-side: nunca confia em contratos, códigos ou valores enviados pelo navegador. */
export async function prepararPreviaAdmissaoQuestor(
  body: DadosExternos,
  perfil?: PerfilUsuario
): Promise<QuestorExportacaoPreviaDto> {
  const { processoIds } = questorExportacaoPreviaRequisicaoSchema.parse(body);
  const empresaId = empresaDoAtor(perfil);

  const registros = await Promise.all(
    processoIds.map(async (processoId) => {
      const processo = await obterProcessoRepository(processoId, empresaId);
      const base = {
        processoId,
        situacao: "bloqueado" as const,
        fichaAprovada: processo?.fichaSituacao === "aprovada",
        quantidadeLinhas: 0,
        pendencias: [] as string[],
        diagnosticos: [] as string[]
      };
      if (!processo) return { ...base, pendencias: ["Processo de admissão não encontrado"] };
      if (processo.status === "cancelado") return { ...base, pendencias: ["Processo cancelado"] };
      if (processo.fichaSituacao !== "aprovada")
        return { ...base, pendencias: ["A ficha precisa estar aprovada pelo DP"] };

      return comMigrationQuestor(async () => {
        const [snapshot, questor] = await Promise.all([
          lerSnapshotQuestorRepository(processoId, empresaId),
          lerParametrosQuestorRepository(processoId, empresaId)
        ]);
        if (!snapshot) return { ...base, pendencias: ["Processo de admissão não encontrado"] };
        const contrato = questor ? { ...snapshot, questor } : snapshot;
        const arquivo = prepararArquivoAdmissaoQuestor([contrato]);
        const pendencias = arquivo.pendencias.map((item) => `${item.registro}.${item.campo}: ${item.motivo}`);
        const diagnosticos = arquivo.diagnosticos.map(
          (item) => `${item.registro ?? "?"}.${item.campo ?? "?"}: ${item.mensagem}`
        );
        const quantidadeLinhas = arquivo.linhas.length;
        const valido = arquivo.valido && pendencias.length === 0;
        return {
          ...base,
          situacao: valido ? ("pronto" as const) : ("bloqueado" as const),
          quantidadeLinhas,
          pendencias,
          diagnosticos: diagnosticos.length
            ? diagnosticos
            : ["A exportação oficial ainda depende de homologação da Conplus"]
        };
      });
    })
  );

  return {
    tipo: "admissao",
    exportacaoDisponivel: false,
    homologacaoConplusConfirmada: false,
    bloqueio: "QUESTOR_EXPORTACAO_NAO_HOMOLOGADA",
    registros
  };
}

export async function listarHistoricoExportacoesQuestor(query: DadosExternos, perfil?: PerfilUsuario) {
  const filtro = questorExportacoesQuerySchema.parse(query ?? {});
  return comMigrationQuestor(() =>
    listarQuestorExportacoesRepository(empresaDoAtor(perfil), filtro.tipo, filtro.limite)
  );
}

/** Geração operacional: somente passa quando os dois gates de configuração estiverem ativos. */
export async function gerarArquivoAdmissaoQuestor(body: DadosExternos, perfil?: PerfilUsuario) {
  if (!env.CONPLUS_QUESTOR_EXPORT_ENABLED || !env.CONPLUS_QUESTOR_EXPORT_HOMOLOGADA) {
    throw naoProcessavel(
      "A exportação operacional do Questor está bloqueada até a homologação oficial da Conplus",
      "QUESTOR_EXPORTACAO_NAO_HOMOLOGADA"
    );
  }
  const { processoIds } = questorExportacaoPreviaRequisicaoSchema.parse(body);
  const empresaId = empresaDoAtor(perfil);
  const usuarioId = atorDoPerfil(perfil);
  return comMigrationQuestor(async () => {
    const contratos: SnapshotAdmissaoPralis[] = [];
    for (const processoId of processoIds) {
      const processo = await obterProcessoRepository(processoId, empresaId);
      if (!processo || processo.fichaSituacao !== "aprovada" || processo.status === "cancelado") {
        throw naoProcessavel(
          "Todos os processos precisam existir, estar aprovados e não cancelados",
          "QUESTOR_PROCESSO_NAO_EXPORTAVEL"
        );
      }
      const [snapshot, questor] = await Promise.all([
        lerSnapshotQuestorRepository(processoId, empresaId),
        lerParametrosQuestorRepository(processoId, empresaId)
      ]);
      if (!snapshot) throw naoProcessavel("Dados da admissão não encontrados", "QUESTOR_SNAPSHOT_AUSENTE");
      contratos.push(questor ? { ...snapshot, questor } : snapshot);
    }
    const arquivo = prepararArquivoAdmissaoQuestor(contratos);
    if (!arquivo.valido) {
      throw naoProcessavel(
        "A admissão possui pendências no layout oficial do Questor",
        "QUESTOR_EXPORTACAO_INVALIDA",
        arquivo.diagnosticos.map((item) => item.mensagem)
      );
    }
    const sha256 = createHash("sha256").update(arquivo.conteudo, "utf8").digest("hex");
    const chaveIdempotencia = `admissao:${sha256}`;
    const exportacao = await banco.transaction(async (tx) => {
      const [inserida] = await tx
        .insert(questorExportacoes)
        .values({
          empresaId,
          tipo: "admissao",
          layoutVersao: "questor-admissao-v2",
          sha256,
          chaveIdempotencia,
          resultado: "gerado",
          nomeArquivo: `admissao-${sha256.slice(0, 12)}.txt`,
          diagnosticos: [],
          geradoPor: usuarioId
        })
        .onConflictDoNothing()
        .returning({ id: questorExportacoes.id });
      if (inserida) {
        await tx.insert(questorExportacoesAdmissoes).values(
          processoIds.map((processoId) => ({
            exportacaoId: inserida.id,
            processoId,
            empresaId
          }))
        );
      }
      return inserida;
    });
    return {
      conteudo: arquivo.conteudo,
      nomeArquivo: `admissao-${sha256.slice(0, 12)}.txt`,
      sha256,
      reutilizado: !exportacao
    };
  });
}
