import type { FastifyInstance } from "fastify";
import { exigirPermissao } from "../auth/guards.js";
import { ok } from "@padaria/shared/api";
import {
  gerarArquivoAdmissaoQuestor,
  listarHistoricoExportacoesQuestor,
  prepararPreviaAdmissaoQuestor
} from "./questor-exportacao.service.js";

/** Prévia somente leitura. Não cria arquivo, não grava banco e não expõe download oficial. */
export async function registrarRotasQuestorExportacao(app: FastifyInstance): Promise<void> {
  app.post(
    "/api/conplus/questor/exportacoes/admissoes/previa",
    { preHandler: exigirPermissao("conplus_exportar_admissoes") },
    async (request) => ok(await prepararPreviaAdmissaoQuestor(request.body, request.perfilUsuario))
  );
  app.get(
    "/api/conplus/questor/exportacoes",
    { preHandler: exigirPermissao("conplus_exportar_admissoes") },
    async (request) => ok(await listarHistoricoExportacoesQuestor(request.query, request.perfilUsuario))
  );
  app.post(
    "/api/conplus/questor/exportacoes/admissoes/download",
    { preHandler: exigirPermissao("conplus_exportar_admissoes") },
    async (request, reply) => {
      const arquivo = await gerarArquivoAdmissaoQuestor(request.body, request.perfilUsuario);
      return reply
        .type("text/plain; charset=utf-8")
        .header("Content-Disposition", `attachment; filename="${arquivo.nomeArquivo}"`)
        .send(arquivo.conteudo);
    }
  );
}
