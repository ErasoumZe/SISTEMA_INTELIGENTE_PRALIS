import type { PerfilUsuario } from "@padaria/shared";
import type { DadosExternos } from "@padaria/shared/api";
import {
  questorEventosVariaveisCatalogoSchema,
  questorEventosVariaveisLancamentoSchema,
  questorEventosVariaveisPreviaSchema,
  questorEventosVariaveisQuerySchema
} from "@padaria/shared/conplus";
import { atorDoPerfil, empresaDoAtor } from "../admissoes/ator.js";
import { conflito, naoEncontrado, naoProcessavel } from "../erros.js";
import { comMigrationQuestor } from "./questor-comum.service.js";
import {
  buscarLancamentosVariaveisRepository,
  inserirEventoVariavelRepository,
  inserirLancamentoVariavelRepository,
  listarLancamentosVariaveisRepository,
  listarEventosVariaveisRepository
} from "./questor-eventos.repository.js";

export function listarEventosVariaveis(perfil?: PerfilUsuario) {
  return comMigrationQuestor(() => listarEventosVariaveisRepository(empresaDoAtor(perfil)));
}

export async function listarLancamentosVariaveis(query: DadosExternos, perfil?: PerfilUsuario) {
  const filtro = questorEventosVariaveisQuerySchema.parse(query ?? {});
  return comMigrationQuestor(() => listarLancamentosVariaveisRepository(empresaDoAtor(perfil), filtro.competencia));
}

export async function criarEventoVariavel(body: DadosExternos, perfil?: PerfilUsuario) {
  const dados = questorEventosVariaveisCatalogoSchema.parse(body);
  const criado = await comMigrationQuestor(() =>
    inserirEventoVariavelRepository(empresaDoAtor(perfil), { ...dados, criadoPor: atorDoPerfil(perfil) })
  );
  if (criado.length === 0) throw conflito("O evento já existe no catálogo desta empresa", "QUESTOR_EVENTO_DUPLICADO");
  return criado[0];
}

export async function criarLancamentoVariavel(body: DadosExternos, perfil?: PerfilUsuario) {
  const dados = questorEventosVariaveisLancamentoSchema.parse(body);
  const resultado = await comMigrationQuestor(() =>
    inserirLancamentoVariavelRepository(empresaDoAtor(perfil), { ...dados, criadoPor: atorDoPerfil(perfil) })
  );
  if (resultado.kind === "vinculo_inexistente") throw naoEncontrado("Vínculo do colaborador não encontrado");
  if (resultado.kind === "evento_inexistente") throw naoEncontrado("Evento não encontrado no catálogo da empresa");
  if (resultado.kind === "unidade_nao_catalogada")
    throw naoProcessavel("A unidade não está autorizada no catálogo do evento", "QUESTOR_UNIDADE_NAO_CATALOGADA");
  if (resultado.kind === "duplicado")
    throw conflito("Já existe lançamento para este colaborador, competência e evento", "QUESTOR_LANCAMENTO_DUPLICADO");
  return resultado.linha;
}

export async function validarPreviaEventosVariaveis(body: DadosExternos, perfil?: PerfilUsuario) {
  const dados = questorEventosVariaveisPreviaSchema.parse(body);
  const empresaId = empresaDoAtor(perfil);
  const lancamentos = await comMigrationQuestor(() =>
    buscarLancamentosVariaveisRepository(empresaId, dados.lancamentoIds)
  );
  if (lancamentos.length !== dados.lancamentoIds.length)
    throw naoEncontrado("Um ou mais lançamentos não pertencem à empresa do usuário");
  return {
    tipo: "eventos_variaveis" as const,
    exportacaoDisponivel: false as const,
    homologacaoConplusConfirmada: false as const,
    bloqueio: "QUESTOR_EXPORTACAO_NAO_HOMOLOGADA" as const,
    competencia: dados.competencia,
    quantidadeRegistros: lancamentos.length,
    diagnosticos: ["A exportação operacional permanece bloqueada até layout e códigos oficiais da Conplus"]
  };
}
