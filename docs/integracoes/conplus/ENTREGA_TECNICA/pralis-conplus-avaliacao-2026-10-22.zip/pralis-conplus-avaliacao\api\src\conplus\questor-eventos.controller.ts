import type { FastifyInstance } from "fastify";
import { ok } from "@padaria/shared/api";
import { exigirPermissao } from "../auth/guards.js";
import {
  criarEventoVariavel,
  criarLancamentoVariavel,
  listarEventosVariaveis,
  listarLancamentosVariaveis,
  validarPreviaEventosVariaveis
} from "./questor-eventos.service.js";

export async function registrarRotasQuestorEventos(app: FastifyInstance): Promise<void> {
  const opcoes = { preHandler: exigirPermissao("conplus_exportar_eventos") };
  app.get("/api/conplus/questor/eventos", opcoes, async (request) =>
    ok(await listarEventosVariaveis(request.perfilUsuario))
  );
  app.get("/api/conplus/questor/eventos/lancamentos", opcoes, async (request) =>
    ok(await listarLancamentosVariaveis(request.query ?? {}, request.perfilUsuario))
  );
  app.post("/api/conplus/questor/eventos", opcoes, async (request, reply) =>
    reply.status(201).send({ data: await criarEventoVariavel(request.body ?? {}, request.perfilUsuario) })
  );
  app.post("/api/conplus/questor/eventos/lancamentos", opcoes, async (request, reply) =>
    reply.status(201).send({ data: await criarLancamentoVariavel(request.body ?? {}, request.perfilUsuario) })
  );
  app.post("/api/conplus/questor/exportacoes/eventos/previa", opcoes, async (request) =>
    ok(await validarPreviaEventosVariaveis(request.body ?? {}, request.perfilUsuario))
  );
}
