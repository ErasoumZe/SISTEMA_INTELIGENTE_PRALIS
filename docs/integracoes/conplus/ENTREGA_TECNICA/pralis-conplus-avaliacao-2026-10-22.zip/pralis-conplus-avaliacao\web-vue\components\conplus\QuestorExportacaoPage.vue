<script setup lang="ts">
import { ErroApiCliente, useApi } from "~/composables/useApi";
import { usePermissoes } from "~/composables/usePermissoes";
import type { AuthSession } from "@padaria/shared";

type Processo = { id: string; nomeCompleto: string | null };
type Previa = {
  bloqueio: string;
  registros: Array<{
    processoId: string;
    situacao: "pronto" | "bloqueado";
    quantidadeLinhas: number;
    pendencias: string[];
    diagnosticos: string[];
  }>;
};
type Lancamento = {
  id: string;
  competencia: string;
  vinculoId: string;
  eventoId: string;
  unidade: string;
  valor: string;
};
type HistoricoExportacao = {
  id: string;
  tipo: string;
  layoutVersao: string;
  resultado: string;
  sha256: string;
  criadoEm: string;
};

const { apiUrl, apiGet, apiPost, carregarSessao } = useApi();
const sessao = ref<AuthSession | null>(null);
const { temPermissao } = usePermissoes(
  computed(() => sessao.value?.perfil?.permissoes ?? []),
  true
);
const processos = ref<Processo[]>([]);
const selecionados = ref<string[]>([]);
const previa = ref<Previa | null>(null);
const eventos = ref<Array<{ id: string; codigo: string; descricao: string; unidades: string[] }>>([]);
const eventosErro = ref("");
const lancamentos = ref<Lancamento[]>([]);
const selecionadosLancamentos = ref<string[]>([]);
const competenciaEventos = ref("");
const previaEventos = ref<{ quantidadeRegistros: number; diagnosticos: string[] } | null>(null);
const historico = ref<HistoricoExportacao[]>([]);
const historicoErro = ref("");
const baixandoProcesso = ref("");
const carregando = ref(false);
const erro = ref("");

async function carregarProcessos() {
  carregando.value = true;
  erro.value = "";
  try {
    const resultado = await apiGet<{ itens: Processo[] }>("/api/admissoes/processos?ficha=aprovada&page=1&pageSize=50");
    processos.value = resultado.itens;
  } catch (falha) {
    erro.value = falha instanceof ErroApiCliente ? falha.message : "Não foi possível carregar as admissões aprovadas.";
  } finally {
    carregando.value = false;
  }
}

async function prepararPrevia() {
  if (!selecionados.value.length || carregando.value) return;
  carregando.value = true;
  erro.value = "";
  previa.value = null;
  try {
    previa.value = await apiPost<Previa>("/api/conplus/questor/exportacoes/admissoes/previa", {
      processoIds: selecionados.value
    });
  } catch (falha) {
    erro.value = falha instanceof ErroApiCliente ? falha.message : "Não foi possível preparar a prévia Questor.";
  } finally {
    carregando.value = false;
  }
}

async function carregarEventos() {
  if (!temPermissao("conplus_exportar_eventos")) return;
  eventosErro.value = "";
  try {
    eventos.value =
      await apiGet<Array<{ id: string; codigo: string; descricao: string; unidades: string[] }>>(
        "/api/conplus/questor/eventos"
      );
    await carregarLancamentos();
  } catch (falha) {
    eventosErro.value = falha instanceof ErroApiCliente ? falha.message : "Catálogo de eventos indisponível.";
  }
}

async function carregarLancamentos() {
  const sufixo = competenciaEventos.value ? `?competencia=${encodeURIComponent(competenciaEventos.value)}` : "";
  lancamentos.value = await apiGet<Lancamento[]>(`/api/conplus/questor/eventos/lancamentos${sufixo}`);
}

async function carregarHistorico() {
  if (!temPermissao("conplus_exportar_admissoes")) return;
  historicoErro.value = "";
  try {
    historico.value = await apiGet<HistoricoExportacao[]>("/api/conplus/questor/exportacoes?limite=20");
  } catch (falha) {
    historicoErro.value = falha instanceof ErroApiCliente ? falha.message : "Histórico de exportações indisponível.";
  }
}

async function prepararPreviaEventos() {
  if (!competenciaEventos.value || !selecionadosLancamentos.value.length) return;
  previaEventos.value = await apiPost("/api/conplus/questor/exportacoes/eventos/previa", {
    competencia: competenciaEventos.value,
    lancamentoIds: selecionadosLancamentos.value
  });
}

async function baixarAdmissao(processoId: string) {
  if (baixandoProcesso.value) return;
  baixandoProcesso.value = processoId;
  erro.value = "";
  try {
    const resposta = await fetch(`${apiUrl}/api/conplus/questor/exportacoes/admissoes/download`, {
      method: "POST",
      credentials: "include",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ processoIds: [processoId] })
    });
    if (!resposta.ok) throw new ErroApiCliente("Download bloqueado pela homologação do Questor.", resposta.status);
    const url = URL.createObjectURL(await resposta.blob());
    const link = document.createElement("a");
    link.href = url;
    link.download = `admissao-${processoId}.txt`;
    link.click();
    URL.revokeObjectURL(url);
  } catch (falha) {
    erro.value = falha instanceof ErroApiCliente ? falha.message : "Não foi possível baixar o arquivo Questor.";
  } finally {
    baixandoProcesso.value = "";
  }
}

onMounted(async () => {
  sessao.value = await carregarSessao();
  await Promise.all([carregarProcessos(), carregarEventos(), carregarHistorico()]);
});
</script>

<template>
  <section class="questor-exportacao">
    <header class="questor-exportacao__cabecalho">
      <div>
        <p class="eyebrow">Departamento pessoal</p>
        <h1>Exportações Questor</h1>
        <p class="muted">
          Prévia técnica baseada nos dados persistidos. Nenhum arquivo oficial é liberado nesta etapa.
        </p>
      </div>
      <v-btn variant="outlined" prepend-icon="mdi-refresh" :loading="carregando" @click="carregarProcessos"
        >Atualizar</v-btn
      >
    </header>

    <v-alert v-if="erro" type="error" variant="tonal" class="mb-4">{{ erro }}</v-alert>
    <v-alert type="warning" variant="tonal" class="mb-4">
      Exportação oficial bloqueada até a homologação da Conplus e a persistência de auditoria da exportação.
    </v-alert>

    <v-card v-if="temPermissao('conplus_exportar_admissoes')" variant="outlined">
      <v-card-title>Admissões aprovadas</v-card-title>
      <v-card-text>
        <v-checkbox
          v-for="processo in processos"
          :key="processo.id"
          v-model="selecionados"
          :value="processo.id"
          hide-details
        >
          <template #label>
            <span
              >{{ processo.nomeCompleto || "Processo sem nome" }} <small class="muted">({{ processo.id }})</small></span
            >
          </template>
        </v-checkbox>
        <p v-if="!processos.length && !carregando" class="muted">Nenhuma ficha aprovada disponível para prévia.</p>
        <v-btn color="primary" :disabled="!selecionados.length" :loading="carregando" @click="prepararPrevia"
          >Preparar prévia técnica</v-btn
        >
      </v-card-text>
    </v-card>

    <v-card v-if="temPermissao('conplus_exportar_eventos')" variant="outlined" class="mt-4">
      <v-card-title>Eventos variáveis — CSV</v-card-title>
      <v-card-text>
        <v-alert v-if="eventosErro" type="warning" variant="tonal" class="mb-3">{{ eventosErro }}</v-alert>
        <v-alert type="info" variant="tonal" class="mb-3">
          O CSV operacional permanece bloqueado até a Conplus confirmar o layout, os códigos e as unidades da empresa.
          Nenhum código é criado automaticamente.
        </v-alert>
        <div v-if="eventos.length" class="eventos-catalogo">
          <strong>Catálogo ativo da empresa</strong>
          <div v-for="evento in eventos" :key="evento.id" class="evento-linha">
            <span>{{ evento.codigo }} — {{ evento.descricao }}</span>
            <small>{{ evento.unidades.join(", ") }}</small>
          </div>
        </div>
        <p v-else class="muted">Nenhum evento oficial foi cadastrado para esta empresa.</p>
        <v-text-field
          v-model="competenciaEventos"
          type="date"
          label="Competência"
          variant="outlined"
          density="comfortable"
          class="mt-4"
          @change="carregarLancamentos"
        />
        <div v-if="lancamentos.length" class="eventos-catalogo">
          <strong>Lançamentos persistidos</strong>
          <v-checkbox
            v-for="lancamento in lancamentos"
            :key="lancamento.id"
            v-model="selecionadosLancamentos"
            :value="lancamento.id"
            hide-details
            density="compact"
            :label="`${lancamento.vinculoId} — evento ${lancamento.eventoId} — ${lancamento.valor} ${lancamento.unidade}`"
          />
          <v-btn
            color="primary"
            variant="outlined"
            :disabled="!competenciaEventos || !selecionadosLancamentos.length"
            @click="prepararPreviaEventos"
            >Preparar prévia CSV</v-btn
          >
        </div>
        <v-alert v-if="previaEventos" type="info" variant="tonal" class="mt-3">
          {{ previaEventos.quantidadeRegistros }} lançamento(s) selecionado(s).
          {{ previaEventos.diagnosticos.join(" ") }}
        </v-alert>
      </v-card-text>
    </v-card>

    <v-card v-if="previa" variant="outlined" class="mt-4">
      <v-card-title>Resultado da prévia</v-card-title>
      <v-card-text>
        <v-alert type="info" variant="tonal" class="mb-4"
          >{{ previa.bloqueio }} — nenhum TXT foi gerado para importação.</v-alert
        >
        <div v-for="registro in previa.registros" :key="registro.processoId" class="resultado">
          <strong>{{ registro.processoId }}</strong>
          <span :class="registro.situacao === 'pronto' ? 'ok' : 'bloqueado'">{{ registro.situacao }}</span>
          <span>{{ registro.quantidadeLinhas }} linha(s) calculada(s)</span>
          <v-btn
            v-if="registro.situacao === 'pronto'"
            size="small"
            variant="outlined"
            :loading="baixandoProcesso === registro.processoId"
            @click="baixarAdmissao(registro.processoId)"
            >Baixar TXT técnico</v-btn
          >
          <ul v-if="registro.pendencias.length || registro.diagnosticos.length">
            <li v-for="item in [...registro.pendencias, ...registro.diagnosticos]" :key="item">{{ item }}</li>
          </ul>
        </div>
      </v-card-text>
    </v-card>

    <v-card v-if="temPermissao('conplus_exportar_admissoes')" variant="outlined" class="mt-4">
      <v-card-title>Histórico de exportações</v-card-title>
      <v-card-text>
        <v-alert v-if="historicoErro" type="warning" variant="tonal" class="mb-3">{{ historicoErro }}</v-alert>
        <div v-if="historico.length" class="eventos-catalogo">
          <div v-for="item in historico" :key="item.id" class="evento-linha">
            <span>{{ item.tipo }} — {{ item.resultado }} — {{ item.layoutVersao }}</span>
            <small>{{ item.sha256.slice(0, 12) }}…</small>
          </div>
        </div>
        <p v-else-if="!historicoErro" class="muted">Nenhuma exportação registrada.</p>
      </v-card-text>
    </v-card>
  </section>
</template>

<style scoped>
.questor-exportacao {
  max-width: 1100px;
  margin: 0 auto;
  padding: 24px;
}
.questor-exportacao__cabecalho {
  display: flex;
  justify-content: space-between;
  gap: 16px;
  align-items: flex-start;
  margin-bottom: 20px;
}
.eyebrow {
  color: rgb(var(--v-theme-primary));
  font-size: 0.75rem;
  text-transform: uppercase;
  letter-spacing: 0.08em;
}
.muted {
  color: rgba(var(--v-theme-on-surface), 0.68);
}
.resultado {
  display: grid;
  gap: 6px;
  border-top: 1px solid rgba(var(--v-border-color), 0.2);
  padding: 14px 0;
}
.ok {
  color: rgb(var(--v-theme-success));
}
.bloqueado {
  color: rgb(var(--v-theme-error));
}
.eventos-catalogo {
  display: grid;
  gap: 8px;
}
.evento-linha {
  display: flex;
  justify-content: space-between;
  gap: 16px;
  border-top: 1px solid rgba(var(--v-border-color), 0.2);
  padding-top: 8px;
}
@media (max-width: 600px) {
  .questor-exportacao {
    padding: 16px;
  }
  .questor-exportacao__cabecalho {
    flex-direction: column;
  }
}
</style>
