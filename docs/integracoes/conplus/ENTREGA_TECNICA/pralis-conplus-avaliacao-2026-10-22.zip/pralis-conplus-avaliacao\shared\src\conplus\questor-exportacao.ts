import { z } from "zod";

/** Contratos da prévia local. A geração oficial permanece bloqueada até haver persistência/auditoria homologada. */
export const questorExportacaoPreviaRequisicaoSchema = z
  .object({
    processoIds: z.array(z.string().uuid()).min(1).max(50)
  })
  .strict();

export type QuestorExportacaoPreviaRequisicao = z.infer<typeof questorExportacaoPreviaRequisicaoSchema>;

export type QuestorExportacaoPreviaRegistro = {
  processoId: string;
  situacao: "pronto" | "bloqueado";
  fichaAprovada: boolean;
  quantidadeLinhas: number;
  pendencias: readonly string[];
  diagnosticos: readonly string[];
};

export type QuestorExportacaoPreviaDto = {
  tipo: "admissao";
  exportacaoDisponivel: false;
  homologacaoConplusConfirmada: false;
  bloqueio: "QUESTOR_EXPORTACAO_NAO_HOMOLOGADA";
  registros: readonly QuestorExportacaoPreviaRegistro[];
};

export const questorEventosVariaveisCatalogoSchema = z
  .object({
    codigo: z.string().regex(/^\d+$/u).max(20),
    descricao: z.string().trim().min(1).max(200),
    unidades: z
      .array(z.enum(["H", "R", "V"]))
      .min(1)
      .max(3)
  })
  .strict();

export const questorEventosVariaveisLancamentoSchema = z
  .object({
    competencia: z.string().regex(/^\d{4}-\d{2}-\d{2}$/u),
    vinculoId: z.string().uuid(),
    eventoId: z.string().uuid(),
    unidade: z.enum(["H", "R", "V"]),
    valor: z.string().regex(/^\d+(\.\d{1,4})?$/u)
  })
  .strict();

export type QuestorEventosVariaveisCatalogo = z.infer<typeof questorEventosVariaveisCatalogoSchema>;
export type QuestorEventosVariaveisLancamento = z.infer<typeof questorEventosVariaveisLancamentoSchema>;

export const questorEventosVariaveisPreviaSchema = z
  .object({
    competencia: z.string().regex(/^\d{4}-\d{2}-\d{2}$/u),
    lancamentoIds: z.array(z.string().uuid()).min(1).max(10_000)
  })
  .strict();

export const questorEventosVariaveisQuerySchema = z
  .object({
    competencia: z
      .string()
      .regex(/^\d{4}-\d{2}-\d{2}$/u)
      .optional()
  })
  .strict();

export const questorExportacoesQuerySchema = z
  .object({
    tipo: z.enum(["admissao", "eventos_variaveis"]).optional(),
    limite: z.coerce.number().int().min(1).max(100).default(50)
  })
  .strict();
