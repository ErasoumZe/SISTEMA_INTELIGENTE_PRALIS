# 6. CSV de eventos variáveis

Base: Questor Docs — "Eventos Variáveis - Importação de Planilha - Dados por Arquivo CSV"
(versão 23.3.0.0+, menu Cálculo / Eventos Variáveis / Importação Planilha).

## Estrutura gerada

| Linha | Conteúdo |
| --- | --- |
| 1 | códigos dos eventos, a partir da coluna 3 |
| 2 | letra de cada evento, a partir da coluna 3: **H** horas · **V** valor · **R** referência |
| 3 | título (não importado pelo Questor) |
| 4+ | coluna 1 = código do empregado no Questor; coluna 2 não avaliada; demais = valores |

Separador `;`, vírgula decimal sem milhar, colunas vazias aceitas. Horas seguem a configuração
"Utiliza Hora Centesimal" **da empresa**: 1h30 sai `1,30` (sexagesimal) ou `1,50` (centesimal), e
minuto ≥ 60 é recusado quando a empresa não usa hora centesimal.

## Regras de segurança

- **Nenhum código de evento é fixo no código.** Os eventos vêm do catálogo **de cada empresa**; um
  código válido numa empresa pode ser recusado em outra.
- Empregado repetido no mesmo arquivo é recusado (o Questor duplicaria o lançamento).
- A geração para uso real está bloqueada.

## Situação (22/10/2026)

| Item | Situação |
| --- | --- |
| Gerador e leitor do CSV | **Implementados e testados** (funções puras, sem banco) |
| `GET/POST /api/conplus/questor/eventos` — catálogo de eventos da empresa | **Implementado**, autenticado e limitado à empresa da sessão |
| `GET/POST /api/conplus/questor/eventos/lancamentos` — lançamentos por competência | **Implementado**, idem |
| `POST /api/conplus/questor/exportacoes/eventos/previa` — prévia do CSV | **Implementado**; escrita operacional bloqueada |
| Tabelas do catálogo e dos lançamentos | SQL em `db/migrations/0068_questor_exportacoes.sql`, **pendente de journal/snapshot** (ver documento 5) |

**Depende da Conplus:** o **modelo CSV anexado ao e-mail de 07/10/2026 não foi recebido** pelo time
técnico; precisamos dele e do catálogo de eventos (código + letra H/R/V) **por empresa**, além do
"código do empregado" usado pelo Questor para cada contrato.
