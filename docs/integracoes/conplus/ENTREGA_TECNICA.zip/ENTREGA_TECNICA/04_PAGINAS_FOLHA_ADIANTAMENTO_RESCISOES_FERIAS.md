# 4. As quatro páginas do Departamento Pessoal

São relatórios **recebidos** da Conplus (sentido Conplus → Pralís). Não confundir com os arquivos que
o Pralís **envia** ao Questor (documentos 5 e 6).

Rotas: `/conplus/folha-05`, `/conplus/adiantamento-20`, `/conplus/rescisoes`, `/conplus/ferias`.

| Página | Leitura do arquivo | Persistência / histórico | Google (prévia) | Situação |
| --- | --- | --- | --- | --- |
| **Rescisões** | TXT de rescisões calculadas (colunas alinhadas) | Prévia → confirmação idempotente → PostgreSQL → consulta/histórico/retificação | Prévia somente leitura | **Implementado e testado** com arquivo fictício |
| **Férias** | CSV de períodos aquisitivos (`;`) | Idem | Prévia somente leitura | **Implementado** com arquivo fictício (ver ressalva abaixo) |
| **Folha 05** | **Bloqueada**: "Este formato ainda não possui leitor seguro" | Estrutura de tela pronta (colunas da planilha do DP) | — | **Depende do layout oficial** do arquivo/relatório |
| **Adiantamento 20** | **Bloqueada**, mesmo motivo | Idem | — | **Depende do layout oficial** |

## Ressalvas, sem rodeios

- Os leitores de Rescisões e Férias foram construídos sobre **exemplos locais**, não sobre um
  layout oficial enviado pela Conplus. Precisamos do layout oficial para homologá-los.
- No teste de integração atual, a rota de sincronização Google de **Férias** responde 500 em vez de
  "desabilitada" quando as credenciais Google estão vazias. A sincronização real está desligada;
  o defeito está registrado e não afeta a leitura/persistência.
- As colunas exibidas em Folha 05 e Adiantamento 20 vêm da planilha usada hoje pelo DP. **Não
  presumimos** que essa seja a estrutura do arquivo da Conplus.

## O que precisamos (detalhe no documento 7)

Layout oficial (ou endpoint da API) dos relatórios de Folha dia 05, Adiantamento dia 20, Rescisões e
Férias, com exemplos fictícios completos e a identificação de empresa, competência e colaborador.
