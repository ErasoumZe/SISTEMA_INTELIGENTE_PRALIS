# 5. Exportação TXT de admissão (A/B/C/D)

Base: documentação "ERP Parceiro x Questor Folha — enviar dados / nfpaadmissaofuncionario" e os
arquivos enviados pela Conplus em 07/10/2026 (`A_FunContratoPre.nli`, `B_…`, `C_…`, `D_…` e os
exemplos `admissao_*.txt`), versionados no pacote em `tests/fixtures/conplus-oficial/` sem alteração.

## Formato gerado

| Item | Regra aplicada | Origem |
| --- | --- | --- |
| Registros | A (contrato preliminar), B (dados obrigatórios), C (não obrigatórios), D (um por dependente) | documentação |
| Ordem | A, B, C e D… por contrato (B/C são detalhe do A; D liga por CNPJ + CPF + data de admissão) | NLI (`itMaster`, `Indice`) |
| Campos por registro | A 21 · B 85 · C 67 · D 32 | documentação e exemplos |
| Separador / decimal / data | `;` · `,` sem milhar · DD/MM/AAAA | NLI |
| Fim de linha | CR+LF em todas as linhas | documentação |
| Valores | nunca truncados; texto acima do tamanho é apontado como inválido | — |

## Validação

Cada linha é conferida contra o layout: tamanho, tipo, data real, domínio (listas da coluna
"Observação"), máscaras (CNPJ, CPF, PIS, CEP), obrigatoriedade, condicionais (descrição do salário;
fato de prazo determinado) e vínculo do dependente com o titular.

**Comparação com os originais:** ler e remontar os quatro exemplos oficiais reproduz cada linha byte
a byte; um arquivo fictício gerado pelo Pralís difere do exemplo oficial só nos placeholders.

## Divergências encontradas nos arquivos oficiais (precisam de resposta)

1. NLI do registro C lê `INDAPREND` e `ORGAOEMISSORRNE` da mesma coluna 64; a documentação põe
   `INDAPREND` na 67.
2. NLI do registro D lê `ENTREGACERT` da coluna 4 (a mesma de `DATAADM`); a documentação diz 32.
3. O exemplo D traz texto onde o layout pede código (`Masculino`, `Educação Superior Completa`),
   `FORMACONTROLEIR = 5` (só 1/2 existem) e omite campos requeridos.
4. No exemplo unificado, a data de admissão do dependente não é a do titular.

Os três campos ambíguos (itens 1 e 2) **ficam sempre vazios** no arquivo gerado até a confirmação.

## Rotas e tela (estado em 22/10/2026)

| Item | Situação |
| --- | --- |
| `POST /api/conplus/questor/exportacoes/admissoes/previa` | **Implementado.** Monta a prévia do PostgreSQL, limitada à empresa da sessão; exige ficha aprovada; valida layout, de-para e vínculo dos dependentes |
| `POST /api/conplus/questor/exportacoes/admissoes/download` | **Implementado, desligado.** Por padrão responde `QUESTOR_EXPORTACAO_NAO_HOMOLOGADA` sem gerar arquivo; falha fechada com ficha não aprovada, pendência de layout ou migration ausente |
| `GET /api/admissoes/processos/:id/questor/prontidao` | **Implementado.** Situação e origem de cada campo, sem dados pessoais |
| Tela `/conplus/exportar` ("Exportações Questor" no Departamento Pessoal) | **Implementada.** Mostra os bloqueios por processo |
| Auditoria das exportações (tabelas `questor_exportacoes*`) | SQL pronto em `db/migrations/0068_questor_exportacoes.sql`, validado em PostgreSQL descartável; **ainda não registrado no journal nem com snapshot** — não é aplicado por nenhum procedimento até ser concluído |

## Liberação

A geração para uso real fica bloqueada enquanto houver pendência, e depende ainda de homologação
explícita (`CONPLUS_QUESTOR_EXPORT_ENABLED` e `CONPLUS_QUESTOR_EXPORT_HOMOLOGADA`, ambos desligados).
Nenhum arquivo é enviado à Conplus automaticamente.
