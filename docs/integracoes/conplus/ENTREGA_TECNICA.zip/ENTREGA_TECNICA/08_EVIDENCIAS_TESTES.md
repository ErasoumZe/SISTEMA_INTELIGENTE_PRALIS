# 8. Evidências dos testes

Executados em 22/10/2026 (última rodada às 13:55) no repositório de desenvolvimento, com dados
**fictícios**. A integração roda contra PostgreSQL 16 **efêmero** (Testcontainers), com Google,
e-mail e demais serviços externos desligados no ambiente do processo. Nenhum banco existente foi usado.

## Integração Questor/Conplus

| Conjunto | Resultado |
| --- | --- |
| Unitários Conplus/Questor + E5 (15 arquivos, inclui exportações TXT/CSV) | **121 de 121** |
| Integração Conplus + E5 (5 arquivos) | **25 de 26** — a falha é a sincronização Google de Férias (abaixo) |
| Integração da admissão com os campos E5 (ficha, dependentes, efetivação, Questor; 7 arquivos) | **58 de 58** |
| Suíte unitária completa do projeto | **63 arquivos, 555 testes** |
| Migrations 0000→0067 pelo migrator oficial, PostgreSQL descartável | **68 de 68** aplicadas; segunda execução sem efeito |
| CHECKs das migrations 0064–0067 (aceita/recusa) | **57 casos** conforme o projetado |
| Typecheck (shared, api, tests), checagem de arquitetura | sem erros |

## O que os testes provam (seleção)

- **Arquivos oficiais da Conplus**: cada campo lido pelos 4 NLI está no layout com a mesma coluna e
  tamanho; ler e remontar os exemplos oficiais reproduz as linhas byte a byte; as únicas divergências
  de coluna entre documentação e NLI são as 3 bloqueadas.
- **Arquivo fictício** gerado pelo Pralís é válido e difere do exemplo oficial só nos placeholders.
- **De-para**: toda opção dos formulários vira um código do domínio oficial ou é pendência declarada.
- **Prévia de prontidão**: só leitura, sem dados pessoais na resposta, isolada por empresa (outra
  empresa → 404), restrita ao DP (Gerência e sem permissão → 403).
- **Configuração e catálogo**: concorrência (409), código fora do catálogo ativo da mesma empresa
  (422), duplicidade (409), corpo com `empresaId` recusado (400).
- **E5**: candidato grava os campos novos pelo link; o DP os vê na revisão; dados de saúde enviados
  no corpo não chegam ao banco.

## Pendências conhecidas, declaradas

- **Sincronização Google de Férias**: com credenciais Google vazias, a rota responde 500 em vez de
  "desabilitada". A sincronização real está desligada; leitura e persistência de Férias passam.
- **Migration 0068 (exportações)**: o arquivo SQL existe, mas ainda não está no journal nem tem
  snapshot. A checagem de migrations do projeto acusa isso até a conclusão — por isso ela não é
  aplicada por nenhum procedimento.
- Fora desta integração, a suíte completa do projeto tem falhas anteriores e independentes (ordem
  histórica das migrations 0061/0062, um teste de fila desatualizado, a lista de rotas públicas sem
  as rotas de anexos).

## Como reproduzir

```bash
npx vitest run --project unit tests/unit/conplus-*.test.ts tests/unit/admissoes-e5-contratos.test.ts
npx vitest run --project integration tests/integration/conplus tests/integration/admissoes/e5-campos-questor.test.ts
```
